<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5>Klinik Sehat</h5>
                <p class="text-muted">
                    Jl. Kesehatan No. 123<br>
                    Kota Sejahtera<br>
                    Telp: (021) 12345678
                </p>
            </div>
            <div class="col-md-3">
                <h5>Jam Operasional</h5>
                <ul class="list-unstyled">
                    <li>Senin-Jumat: 08.00-20.00</li>
                    <li>Sabtu: 08.00-15.00</li>
                    <li>Minggu: Tutup</li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5>Link Cepat</h5>
                <ul class="list-unstyled">
                    <li><a href="../login.php" class="text-decoration-none">Login</a></li>
                    <li><a href="../patient/register.php" class="text-decoration-none">Daftar Pasien</a></li>
                    <li><a href="#" class="text-decoration-none">Kebijakan Privasi</a></li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-12 text-center">
                <p class="text-muted mb-0">&copy; <?php echo date('Y'); ?> Klinik Sehat. All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>

<!-- Script Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Script Font Awesome (jika menggunakan icon) -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

</body>
</html>