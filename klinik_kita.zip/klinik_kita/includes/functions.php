<?php
function getGenderLabel($gender) {
    $genderMap = [
        'M' => 'Laki-laki',
        'male' => 'Laki-laki',
        'F' => 'Perempuan',
        'female' => 'Perempuan'
    ];
    
    return $genderMap[$gender] ?? $gender;
}
?>