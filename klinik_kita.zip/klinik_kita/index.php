<?php
session_start();
include 'config/database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klinik Sehat - Layanan Kesehatan Terbaik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('assets/images/clinic_bg.jpg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 0;
            text-align: center;
        }
        .feature-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #0d6efd;
        }
        .login-box {
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            padding: 30px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-clinic-medical me-2"></i>Klinik Sehat
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Tentang Kami</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#services">Layanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#doctors">Dokter</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Kontak</a>
                    </li>
                    <li class="nav-item ms-lg-3">
                        <a class="btn btn-outline-light" href="login.php">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section mb-5">
        <div class="container">
            <h1 class="display-4 fw-bold mb-4">Kesehatan Anda Prioritas Kami</h1>
            <p class="lead mb-5">Layanan kesehatan terpadu dengan dokter profesional dan fasilitas modern</p>
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="login-box text-center">
    <img src="assets/images/doctor-hero.jpg" alt="Dokter Klinik" class="img-fluid rounded shadow mb-3">
    <h5 class="text-dark">Selamat Datang di Klinik Sehat</h5>
    <p class="text-muted">Kami siap memberikan layanan kesehatan terbaik untuk Anda.</p>
</div>

    </section>

    <!-- About Section -->
    <section id="about" class="py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-4">Tentang Klinik Sehat</h2>
                    <p class="lead">Klinik Sehat telah melayani masyarakat sejak tahun 2010 dengan komitmen memberikan pelayanan kesehatan terbaik.</p>
                    <p>Dengan tim dokter profesional dan fasilitas modern, kami siap memberikan solusi kesehatan untuk Anda dan keluarga.</p>
                    <ul class="list-unstyled">
                        <li class="mb-2"><i class="fas fa-check-circle text-primary me-2"></i> Pelayanan 24 jam untuk keadaan darurat</li>
                        <li class="mb-2"><i class="fas fa-check-circle text-primary me-2"></i> Dokter spesialis berpengalaman</li>
                        <li class="mb-2"><i class="fas fa-check-circle text-primary me-2"></i> Fasilitas pemeriksaan lengkap</li>
                        <li class="mb-2"><i class="fas fa-check-circle text-primary me-2"></i> Asuransi kesehatan diterima</li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <img src="assets/images/clinic-interior.jpg" alt="Interior Klinik" class="img-fluid rounded shadow">
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center fw-bold mb-5">Layanan Kami</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="feature-icon">
                                <i class="fas fa-heartbeat"></i>
                            </div>
                            <h4>Pemeriksaan Umum</h4>
                            <p>Konsultasi dengan dokter umum untuk diagnosa dan pengobatan penyakit umum.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="feature-icon">
                                <i class="fas fa-baby"></i>
                            </div>
                            <h4>Kesehatan Anak</h4>
                            <p>Layanan khusus untuk kesehatan bayi dan anak dengan dokter spesialis anak.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <div class="feature-icon">
                                <i class="fas fa-tooth"></i>
                            </div>
                            <h4>Gigi dan Mulut</h4>
                            <p>Perawatan gigi dan mulut oleh dokter gigi profesional dengan alat modern.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Doctors Section -->
    <section id="doctors" class="py-5">
        <div class="container">
            <h2 class="text-center fw-bold mb-5">Dokter Kami</h2>
            <div class="row g-4">
                <?php
                $doctors = $conn->query("SELECT * FROM doctors LIMIT 3");
                while ($doctor = $doctors->fetch_assoc()):
                ?>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <img src="assets/images/doctors/<?= $doctor['id'] ?>.jpg" class="card-img-top" alt="Dr. <?= $doctor['name'] ?>">
                        <div class="card-body text-center">
                            <h5>Dr. <?= htmlspecialchars($doctor['name']) ?></h5>
                            <p class="text-muted"><?= $doctor['specialization'] ?></p>
                            <p class="small"><?= substr($doctor['bio'], 0, 100) ?>...</p>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
            <div class="text-center mt-4">
                <a href="doctors.php" class="btn btn-outline-primary">Lihat Semua Dokter</a>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-4">Hubungi Kami</h2>
                    <p><i class="fas fa-map-marker-alt text-primary me-2"></i> Jl. Kesehatan No. 123, Kota Sejahtera</p>
                    <p><i class="fas fa-phone-alt text-primary me-2"></i> (021) 12345678</p>
                    <p><i class="fas fa-envelope text-primary me-2"></i> info@kliniksehat.com</p>
                    <p><i class="fas fa-clock text-primary me-2"></i> Buka Setiap Hari: 08.00 - 20.00 WIB</p>
                </div>
                <div class="col-lg-6">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Punya Pertanyaan?</h5>
                            <form>
                                <div class="mb-3">
                                    <input type="text" class="form-control" placeholder="Nama Anda">
                                </div>
                                <div class="mb-3">
                                    <input type="email" class="form-control" placeholder="Email">
                                </div>
                                <div class="mb-3">
                                    <textarea class="form-control" rows="3" placeholder="Pesan Anda"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h5>Klinik Sehat</h5>
                    <p>Memberikan pelayanan kesehatan terbaik dengan penuh kasih sayang dan profesionalisme.</p>
                </div>
                <div class="col-md-4">
                    <h5>Link Cepat</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white text-decoration-none">Tentang Kami</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Layanan</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Dokter</a></li>
                        <li><a href="#" class="text-white text-decoration-none">Kontak</a></li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h5>Hubungi Kami</h5>
                    <p><i class="fas fa-phone-alt me-2"></i> (021) 12345678</p>
                    <p><i class="fas fa-envelope me-2"></i> info@kliniksehat.com</p>
                </div>
            </div>
            <hr>
            <div class="text-center">
                <p class="mb-0">&copy; <?= date('Y') ?> Klinik Sehat. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>