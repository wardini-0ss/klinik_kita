<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];

// Tarif konsultasi berdasarkan spesialisasi dokter
$consultation_fees = [
    'Dokter Umum' => 150000,
    'Dokter Anak' => 200000,
    'Dokter Kandungan' => 250000,
    'Dokter Bedah' => 300000,
    // Tambahkan spesialisasi lain sesuai kebutuhan
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];
    $complaint = $_POST['complaint'];
    
    // Validasi tanggal tidak di masa lalu
    if (strtotime($appointment_date) < strtotime('today')) {
        $error = "Tanggal janji tidak boleh di masa lalu";
    } else {
        // Dapatkan info dokter termasuk spesialisasi
        $doctor_stmt = $conn->prepare("SELECT name, specialization FROM doctors WHERE id = ?");
        $doctor_stmt->bind_param("i", $doctor_id);
        $doctor_stmt->execute();
        $doctor = $doctor_stmt->get_result()->fetch_assoc();
        $doctor_stmt->close();
        
        // Tentukan biaya berdasarkan spesialisasi
        $fee = $consultation_fees[$doctor['specialization']] ?? 200000; // Default 200.000 jika spesialisasi tidak terdaftar
        
        // Buat janji konsultasi
        $stmt = $conn->prepare("
            INSERT INTO appointments 
            (patient_id, doctor_id, appointment_date, complaint, status, consultation_fee) 
            VALUES (?, ?, ?, ?, 'pending', ?)
        ");
        $stmt->bind_param("iissi", $patient_id, $doctor_id, $appointment_date, $complaint, $fee);
        
        if ($stmt->execute()) {
            // Buat record pembayaran
            $appointment_id = $stmt->insert_id;
            $payment_stmt = $conn->prepare("
                INSERT INTO payments 
                (appointment_id, patient_id, amount, status, due_date) 
                VALUES (?, ?, ?, 'pending', DATE_ADD(NOW(), INTERVAL 3 DAY))
            ");
            $payment_stmt->bind_param("iii", $appointment_id, $patient_id, $fee);
            $payment_stmt->execute();
            $payment_stmt->close();
            
            $_SESSION['success'] = "Janji konsultasi berhasil dibuat. Biaya konsultasi: Rp " . number_format($fee, 0, ',', '.');
            header("Location: appointments.php");
            exit();
        } else {
            $error = "Gagal membuat janji: " . $conn->error;
        }
    }
}

// Ambil daftar dokter dengan informasi spesialisasi
$doctors = $conn->query("SELECT id, name, specialization FROM doctors ORDER BY name");
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Buat Janji Konsultasi</h3>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <form method="POST" id="appointmentForm">
                <div class="mb-3">
                    <label class="form-label">Pilih Dokter</label>
                    <select name="doctor_id" id="doctorSelect" class="form-select" required>
                        <option value="">-- Pilih Dokter --</option>
                        <?php while ($doctor = $doctors->fetch_assoc()): ?>
                            <option value="<?= $doctor['id'] ?>" data-specialization="<?= htmlspecialchars($doctor['specialization']) ?>">
                                Dr. <?= htmlspecialchars($doctor['name']) ?> - <?= $doctor['specialization'] ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Tanggal dan Waktu</label>
                    <input type="datetime-local" name="appointment_date" class="form-control" required min="<?= date('Y-m-d\TH:i') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Keluhan</label>
                    <textarea name="complaint" class="form-control" rows="3" required></textarea>
                </div>
                <div class="mb-3 p-3 border rounded bg-light">
                    <h5>Informasi Biaya</h5>
                    <div id="feeInfo">
                        <p class="text-muted">Pilih dokter terlebih dahulu untuk melihat biaya konsultasi</p>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Buat Janji</button>
                <a href="dashboard.php" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>

<script>
// Tarif konsultasi (harus sama dengan di PHP)
const consultationFees = {
    'Dokter Umum': 150000,
    'Dokter Anak': 200000,
    'Dokter Kandungan': 250000,
    'Dokter Bedah': 300000
};

// Update informasi biaya saat dokter dipilih
document.getElementById('doctorSelect').addEventListener('change', function() {
    const feeInfo = document.getElementById('feeInfo');
    const selectedOption = this.options[this.selectedIndex];
    
    if (this.value === '') {
        feeInfo.innerHTML = '<p class="text-muted">Pilih dokter terlebih dahulu untuk melihat biaya konsultasi</p>';
        return;
    }
    
    const specialization = selectedOption.getAttribute('data-specialization');
    const fee = consultationFees[specialization] || 200000;
    
    feeInfo.innerHTML = `
        <p><strong>Spesialisasi:</strong> ${specialization}</p>
        <p><strong>Biaya Konsultasi:</strong> Rp ${fee.toLocaleString('id-ID')}</p>
        <p class="text-muted small">*Biaya dapat berubah sesuai dengan kondisi pasien saat pemeriksaan</p>
    `;
});
</script>

<?php include '../includes/footer.php'; ?>