<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya pasien yang bisa akses
if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

// Ambil ID janji dari parameter URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$appointment_id = $_GET['id'];
$patient_id = $_SESSION['user_id'];

// Query untuk mendapatkan detail janji
$stmt = $conn->prepare("
    SELECT a.*, d.name as doctor_name, d.specialization, d.phone as doctor_phone, 
           d.email as doctor_email, p.name as patient_name, p.phone as patient_phone,
           p.email as patient_email
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    JOIN patients p ON a.patient_id = p.id
    WHERE a.id = ? AND a.patient_id = ?
");
$stmt->bind_param("ii", $appointment_id, $patient_id);
$stmt->execute();
$appointment = $stmt->get_result()->fetch_assoc();

if (!$appointment) {
    header("Location: dashboard.php");
    exit();
}

// Format tanggal dan waktu
$appointment_date = date('d F Y', strtotime($appointment['appointment_date']));
$appointment_time = date('H:i', strtotime($appointment['appointment_time']));

$stmt->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Detail Janji Temu</h4>
                    <span class="badge bg-<?= 
                        $appointment['status'] == 'confirmed' ? 'success' : 
                        ($appointment['status'] == 'pending' ? 'warning' : 'secondary')
                    ?>">
                        <?= ucfirst($appointment['status']) ?>
                    </span>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Informasi Dokter</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <strong>Nama:</strong> <?= htmlspecialchars($appointment['doctor_name']) ?>
                                </li>
                                <li class="list-group-item">
                                    <strong>Spesialisasi:</strong> <?= htmlspecialchars($appointment['specialization']) ?>
                                </li>
                                <li class="list-group-item">
                                    <strong>Kontak:</strong> <?= htmlspecialchars($appointment['doctor_phone']) ?>
                                </li>
                                <li class="list-group-item">
                                    <strong>Email:</strong> <?= htmlspecialchars($appointment['doctor_email']) ?>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h5>Informasi Janji</h5>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <strong>Tanggal:</strong> <?= $appointment_date ?>
                                </li>
                                <li class="list-group-item">
                                    <strong>Waktu:</strong> <?= $appointment_time ?>
                                </li>
                                <li class="list-group-item">
                                    <strong>Keluhan:</strong> <?= htmlspecialchars($appointment['complaint']) ?>
                                </li>
                                <li class="list-group-item">
                                    <strong>Dibuat pada:</strong> <?= date('d F Y H:i', strtotime($appointment['created_at'])) ?>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <?php if (!empty($appointment['notes'])): ?>
                        <div class="alert alert-info">
                            <h5>Catatan Dokter</h5>
                            <p><?= htmlspecialchars($appointment['notes']) ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="dashboard.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-2"></i>Kembali
                        </a>
                        <?php if ($appointment['status'] == 'pending' || $appointment['status'] == 'confirmed'): ?>
                            <a href="cancel_appointment.php?id=<?= $appointment_id ?>" class="btn btn-danger">
                                <i class="fas fa-times me-2"></i>Batalkan Janji
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>