<?php
include '../includes/auth.php';
include '../config/database.php';
if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];
$query = "SELECT p.*, a.appointment_date, d.name AS doctor_name 
          FROM payments p
          JOIN appointments a ON p.appointment_id = a.id
          JOIN doctors d ON a.doctor_id = d.id
          WHERE a.patient_id = ?
          ORDER BY p.created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$payments = $stmt->get_result();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4>Riwayat Pembayaran</h4>
                </div>
                <div class="card-body">
                    <?php if ($payments->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>No. Invoice</th>
                                        <th>Tanggal</th>
                                        <th>Dokter</th>
                                        <th>Jumlah</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($payment = $payments->fetch_assoc()): ?>
                                        <tr>
                                            <td>INV-<?= str_pad($payment['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                            <td><?= date('d M Y', strtotime($payment['appointment_date'])) ?></td>
                                            <td><?= htmlspecialchars($payment['doctor_name']) ?></td>
                                            <td>Rp <?= number_format($payment['amount'], 0, ',', '.') ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $payment['status'] == 'paid' ? 'success' : 
                                                    ($payment['status'] == 'pending' ? 'warning' : 'danger') 
                                                ?>">
                                                    <?= ucfirst($payment['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="payment_detail.php?id=<?= $payment['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                    Detail
                                                </a>
                                                
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Anda belum memiliki riwayat pembayaran.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>