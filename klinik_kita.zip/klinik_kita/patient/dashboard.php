<?php
include '../config/database.php'; 
include '../includes/auth.php';

// Pastikan hanya pasien yang bisa akses
if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];

// Query untuk janji mendatang (7 hari ke depan)
$today = date('Y-m-d');
$next_week = date('Y-m-d', strtotime('+7 days'));

$appointment_stmt = $conn->prepare("
    SELECT a.id, a.appointment_date, a.appointment_time, a.status,
           d.name as doctor_name, d.specialization
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    WHERE a.patient_id = ?
    AND a.appointment_date BETWEEN ? AND ?
    ORDER BY a.appointment_date, a.appointment_time
");
$appointment_stmt->bind_param("iss", $patient_id, $today, $next_week);
$appointment_stmt->execute();
$upcoming_appointments = $appointment_stmt->get_result();

// Query untuk rekam medis terakhir (3 terbaru)
$medical_stmt = $conn->prepare("
    SELECT m.id, m.created_at, m.diagnosis, m.treatment,
           d.name as doctor_name
    FROM medical_records m
    JOIN appointments a ON m.appointment_id = a.id
    JOIN doctors d ON a.doctor_id = d.id
    WHERE a.patient_id = ?
    ORDER BY m.created_at DESC
    LIMIT 3
");
$medical_stmt->bind_param("i", $patient_id);
$medical_stmt->execute();
$medical_records = $medical_stmt->get_result();

// Query untuk statistik
$stats_stmt = $conn->prepare("
    SELECT 
        (SELECT COUNT(*) FROM appointments WHERE patient_id = ? AND appointment_date >= CURDATE()) as upcoming_count,
        (SELECT COUNT(*) FROM prescriptions WHERE patient_id = ? AND is_active = 1) as active_prescriptions,
        (SELECT COUNT(*) FROM payments WHERE patient_id = ? AND status = 'pending') as pending_payments
");
$stats_stmt->bind_param("iii", $patient_id, $patient_id, $patient_id);
$stats_stmt->execute();
$stats = $stats_stmt->get_result()->fetch_assoc();
$stats_stmt->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar Navigation -->
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <div class="text-center mb-4">
                    <img src="../assets/images/user-avatar.jpg" alt="User Avatar" class="rounded-circle" width="80">
                    <h5 class="mt-2"><?php echo $_SESSION['name']; ?></h5>
                    <small class="text-muted">Pasien</small>
                </div>
                
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-home me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="appointment.php">
                            <i class="fas fa-calendar-check me-2"></i>Buat Janji
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="schedule.php">
                            <i class="fas fa-calendar-alt me-2"></i>Jadwal Dokter
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="medical_record.php">
                            <i class="fas fa-file-medical me-2"></i>Rekam Medis
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="prescriptions.php">
                            <i class="fas fa-prescription-bottle me-2"></i>Resep Obat
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="billing.php">
                            <i class="fas fa-receipt me-2"></i>Pembayaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user me-2"></i>Profil Saya
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard Pasien</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Bagikan</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary">Ekspor</button>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                        <span data-feather="calendar"></span> Minggu ini
                    </button>
                </div>
            </div>

            <!-- Info Cards - Diperbarui dengan data dinamis -->
            <div class="row mb-4">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Janji Mendatang</h5>
                                    <h2 class="mb-0"><?= $stats['upcoming_count'] ?></h2>
                                </div>
                                <i class="fas fa-calendar fa-3x opacity-50"></i>
                            </div>
                            <a href="appointment.php" class="text-white stretched-link"></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Resep Aktif</h5>
                                    <h2 class="mb-0"><?= $stats['active_prescriptions'] ?></h2>
                                </div>
                                <i class="fas fa-prescription-bottle fa-3x opacity-50"></i>
                            </div>
                            <a href="prescriptions.php" class="text-white stretched-link"></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-warning mb-3">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h5 class="card-title">Pembayaran Tertunda</h5>
                                    <h2 class="mb-0"><?= $stats['pending_payments'] ?></h2>
                                </div>
                                <i class="fas fa-receipt fa-3x opacity-50"></i>
                            </div>
                            <a href="billing.php" class="text-white stretched-link"></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Upcoming Appointments - Diperbarui dengan data dinamis -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Janji Mendatang</h5>
                </div>
                <div class="card-body">
                    <?php if ($upcoming_appointments->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                        <th>Dokter</th>
                                        <th>Spesialisasi</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($appointment = $upcoming_appointments->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= date('d F Y', strtotime($appointment['appointment_date'])) ?></td>
                                            <td><?= date('H:i', strtotime($appointment['appointment_time'])) ?></td>
                                            <td><?= htmlspecialchars($appointment['doctor_name']) ?></td>
                                            <td><?= htmlspecialchars($appointment['specialization']) ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $appointment['status'] == 'confirmed' ? 'success' : 
                                                    ($appointment['status'] == 'pending' ? 'warning' : 'secondary')
                                                ?>">
                                                    <?= ucfirst($appointment['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="appointment_detail.php?id=<?= $appointment['id'] ?>" class="btn btn-sm btn-outline-primary">Detail</a>
                                                <?php if ($appointment['status'] == 'pending' || $appointment['status'] == 'confirmed'): ?>
                                                    <a href="cancel_appointment.php?id=<?= $appointment['id'] ?>" class="btn btn-sm btn-outline-danger">Batalkan</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Tidak ada janji mendatang.</div>
                    <?php endif; ?>
                    <a href="appointment.php" class="btn btn-primary mt-3">Buat Janji Baru</a>
                </div>
            </div>

            <!-- Recent Medical Records - Diperbarui dengan data dinamis -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Rekam Medis Terakhir</h5>
                </div>
                <div class="card-body">
                    <?php if ($medical_records->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Dokter</th>
                                        <th>Diagnosa</th>
                                        <th>Perawatan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($record = $medical_records->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= date('d F Y', strtotime($record['created_at'])) ?></td>
                                            <td><?= htmlspecialchars($record['doctor_name']) ?></td>
                                            <td><?= htmlspecialchars($record['diagnosis']) ?></td>
                                            <td><?= htmlspecialchars($record['treatment']) ?></td>
                                            <td>
                                                <a href="medical_detail.php?id=<?= $record['id'] ?>" class="btn btn-sm btn-outline-primary">Lihat Detail</a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Belum ada rekam medis.</div>
                    <?php endif; ?>
                    <a href="medical_record.php" class="btn btn-primary mt-3">Lihat Semua Rekam Medis</a>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- CSS Tambahan -->
<style>
    .sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        z-index: 100;
        padding: 48px 0 0;
        box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
    }
    
    .nav-link {
        font-weight: 500;
        color: #333;
        padding: 0.75rem 1rem;
        border-radius: 0.25rem;
    }
    
    .nav-link:hover {
        background-color: rgba(13, 110, 253, 0.1);
        color: #0d6efd;
    }
    
    .nav-link.active {
        color: #0d6efd;
        background-color: rgba(13, 110, 253, 0.1);
    }
    
    .card {
        transition: transform 0.2s;
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .card:hover {
        transform: translateY(-5px);
    }
    
    main {
        margin-left: 280px; /* Sesuaikan dengan lebar sidebar */
        padding-top: 1rem;
    }
    
    @media (max-width: 768px) {
        .sidebar {
            width: 100%;
            height: auto;
            position: relative;
        }
        main {
            margin-left: 0;
        }
    }
</style>

<!-- JavaScript Tambahan -->
<script>
    // Aktifkan tooltips
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })
    
    // Aktifkan popovers
    $(function () {
        $('[data-toggle="popover"]').popover()
    })
</script>