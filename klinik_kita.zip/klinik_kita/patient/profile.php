<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];
$patient = $conn->query("SELECT * FROM patients WHERE id = $patient_id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $birth_date = $_POST['birth_date'];
    $blood_type = $_POST['blood_type'];
    $gender = $_POST['gender'];
    
    // Update password hanya jika diisi
    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE patients SET name = ?, email = ?, phone = ?, address = ?, birth_date = ?, blood_type = ?, gender = ?, password = ? WHERE id = ?");
        $stmt->bind_param("ssssssssi", $name, $email, $phone, $address, $birth_date, $blood_type, $gender, $password, $patient_id);
    } else {
        $stmt = $conn->prepare("UPDATE patients SET name = ?, email = ?, phone = ?, address = ?, birth_date = ?, blood_type = ?, gender = ? WHERE id = ?");
        $stmt->bind_param("sssssssi", $name, $email, $phone, $address, $birth_date, $blood_type, $gender, $patient_id);
    }
    
    if ($stmt->execute()) {
        $_SESSION['name'] = $name;
        $_SESSION['success'] = "Profil berhasil diperbarui";
        header("Location: profile.php");
        exit();
    } else {
        $error = "Gagal memperbarui profil: " . $conn->error;
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Profil Saya</h3>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($patient['name']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($patient['email']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password (Kosongkan jika tidak diubah)</label>
                            <input type="password" name="password" class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tanggal Lahir</label>
                            <input type="date" name="birth_date" class="form-control" value="<?= $patient['birth_date'] ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label">Jenis Kelamin</label>
                            <select name="gender" class="form-select" required>
                                <option value="M" <?= $patient['gender'] == 'M' ? 'selected' : '' ?>>Laki-laki</option>
                                <option value="F" <?= $patient['gender'] == 'F' ? 'selected' : '' ?>>Perempuan</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Golongan Darah</label>
                            <select name="blood_type" class="form-select">
                                <option value="">-- Pilih --</option>
                                <option value="A" <?= $patient['blood_type'] == 'A' ? 'selected' : '' ?>>A</option>
                                <option value="B" <?= $patient['blood_type'] == 'B' ? 'selected' : '' ?>>B</option>
                                <option value="AB" <?= $patient['blood_type'] == 'AB' ? 'selected' : '' ?>>AB</option>
                                <option value="O" <?= $patient['blood_type'] == 'O' ? 'selected' : '' ?>>O</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nomor Telepon</label>
                            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($patient['phone']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <textarea name="address" class="form-control" rows="3" required><?= htmlspecialchars($patient['address']) ?></textarea>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>