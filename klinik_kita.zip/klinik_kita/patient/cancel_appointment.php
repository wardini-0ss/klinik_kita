<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya pasien yang bisa akses
if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

// Ambil ID janji dari parameter URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$appointment_id = $_GET['id'];
$patient_id = $_SESSION['user_id'];

// Verifikasi bahwa janji tersebut milik pasien yang login
$check_stmt = $conn->prepare("
    SELECT id, status FROM appointments 
    WHERE id = ? AND patient_id = ?
");
$check_stmt->bind_param("ii", $appointment_id, $patient_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    header("Location: dashboard.php");
    exit();
}

$appointment = $check_result->fetch_assoc();

// Hanya bisa membatalkan jika status pending atau confirmed
if ($appointment['status'] != 'pending' && $appointment['status'] != 'confirmed') {
    $_SESSION['error_message'] = "Janji tidak dapat dibatalkan karena status sudah " . $appointment['status'];
    header("Location: appointment_detail.php?id=" . $appointment_id);
    exit();
}

// Proses pembatalan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cancel_reason = $_POST['cancel_reason'] ?? '';
    
    // Update status appointment
    $update_stmt = $conn->prepare("
        UPDATE appointments 
        SET status = 'cancelled', cancel_reason = ?, cancelled_at = NOW() 
        WHERE id = ?
    ");
    $update_stmt->bind_param("si", $cancel_reason, $appointment_id);
    
    if ($update_stmt->execute()) {
        $_SESSION['success_message'] = "Janji berhasil dibatalkan";
        $update_stmt->close();
        header("Location: dashboard.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Gagal membatalkan janji";
        $update_stmt->close();
        header("Location: appointment_detail.php?id=" . $appointment_id);
        exit();
    }
}

$check_stmt->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4>Batalkan Janji Temu</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($_SESSION['error_message'])): ?>
                        <div class="alert alert-danger">
                            <?= $_SESSION['error_message'] ?>
                            <?php unset($_SESSION['error_message']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <p>Anda yakin ingin membatalkan janji temu ini?</p>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label for="cancel_reason" class="form-label">Alasan Pembatalan</label>
                            <textarea class="form-control" id="cancel_reason" name="cancel_reason" rows="3" required></textarea>
                        </div>
                        
                        <div class="d-flex justify-content-between">
                            <a href="appointment_detail.php?id=<?= $appointment_id ?>" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-times me-2"></i>Ya, Batalkan Janji
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>