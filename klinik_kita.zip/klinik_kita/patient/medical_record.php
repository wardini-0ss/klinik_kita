<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];

// ✅ Ambil rekam medis berdasarkan appointment yang dimiliki pasien
$sql = "SELECT 
            mr.diagnosis,
            mr.treatment,
            mr.notes,
            mr.created_at AS appointment_date,
            d.name AS doctor_name,
            d.specialization
        FROM medical_records mr
        JOIN appointments a ON mr.appointment_id = a.id
        JOIN doctors d ON a.doctor_id = d.id
        WHERE a.patient_id = $patient_id
        ORDER BY mr.created_at DESC";

$records = $conn->query($sql);
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Rekam Medis Saya</h3>
    
    <?php if ($records && $records->num_rows > 0): ?>
        <div class="accordion" id="recordsAccordion">
            <?php while ($record = $records->fetch_assoc()): ?>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= md5($record['appointment_date']) ?>">
                            <?= date('d/m/Y', strtotime($record['appointment_date'])) ?> - 
                            Dr. <?= htmlspecialchars($record['doctor_name']) ?> (<?= $record['specialization'] ?>)
                        </button>
                    </h2>
                    <div id="collapse<?= md5($record['appointment_date']) ?>" class="accordion-collapse collapse" data-bs-parent="#recordsAccordion">
                        <div class="accordion-body">
                            <div class="mb-3">
                                <h5>Diagnosis</h5>
                                <p><?= nl2br(htmlspecialchars($record['diagnosis'])) ?></p>
                            </div>
                            <div class="mb-3">
                                <h5>Tindakan/Pengobatan</h5>
                                <p><?= nl2br(htmlspecialchars($record['treatment'])) ?></p>
                            </div>
                        
                            <?php if ($record['notes']): ?>
                                <div class="mb-3">
                                    <h5>Catatan Dokter</h5>
                                    <p><?= nl2br(htmlspecialchars($record['notes'])) ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            Belum ada rekam medis yang tersedia.
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>
