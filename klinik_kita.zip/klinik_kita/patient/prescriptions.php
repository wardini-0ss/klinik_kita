<?php
include '../includes/auth.php';
include '../config/database.php';
if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];
$query = "SELECT p.*, d.name AS doctor_name, mr.diagnosis 
          FROM prescriptions p
          JOIN medical_records mr ON p.medical_record_id = mr.id
          JOIN appointments a ON mr.appointment_id = a.id
          JOIN doctors d ON p.doctor_id = d.id
          WHERE a.patient_id = ?
          ORDER BY p.created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$prescriptions = $stmt->get_result();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4>Resep Obat Saya</h4>
                        <a href="#" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#helpModal">
                            <i class="fas fa-question-circle"></i> Bantuan
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if ($prescriptions->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Dokter</th>
                                        <th>Diagnosa</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($prescription = $prescriptions->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= date('d M Y', strtotime($prescription['created_at'])) ?></td>
                                            <td><?= htmlspecialchars($prescription['doctor_name']) ?></td>
                                            <td><?= htmlspecialchars($prescription['diagnosis']) ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $prescription['status'] == 'active' ? 'success' : 
                                                    ($prescription['status'] == 'completed' ? 'info' : 'secondary') 
                                                ?>">
                                                    <?= ucfirst($prescription['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary view-prescription" 
                                                        data-id="<?= $prescription['id'] ?>">
                                                    Lihat Detail
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Anda belum memiliki resep obat.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk Detail Resep -->
<div class="modal fade" id="prescriptionModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detail Resep Obat</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="prescriptionDetail">
                <!-- Konten akan diisi via AJAX -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.view-prescription').click(function() {
        var prescriptionId = $(this).data('id');
        $.ajax({
            url: 'get_prescription.php',
            type: 'GET',
            data: { id: prescriptionId },
            success: function(response) {
                $('#prescriptionDetail').html(response);
                $('#prescriptionModal').modal('show');
            }
        });
    });
});
</script>

<?php include '../includes/footer.php'; ?>