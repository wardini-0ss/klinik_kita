<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];
$appointments = $conn->query("
    SELECT a.id, a.appointment_date, a.status, a.complaint, 
           d.name as doctor_name, d.specialization
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    WHERE a.patient_id = $patient_id
    ORDER BY a.appointment_date DESC
");
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Daftar Janji Konsultasi Saya</h3>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Dokter</th>
                            <th>Spesialisasi</th>
                            <th>Keluhan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($appointment = $appointments->fetch_assoc()): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i', strtotime($appointment['appointment_date'])) ?></td>
                                <td>Dr. <?= htmlspecialchars($appointment['doctor_name']) ?></td>
                                <td><?= $appointment['specialization'] ?></td>
                                <td><?= htmlspecialchars($appointment['complaint']) ?></td>
                                <td>
                                    <span class="badge bg-<?= 
                                        $appointment['status'] == 'confirmed' ? 'success' : 
                                        ($appointment['status'] == 'pending' ? 'warning' : 'secondary') 
                                    ?>">
                                        <?= ucfirst($appointment['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($appointment['status'] == 'pending' && strtotime($appointment['appointment_date']) > time()): ?>
                                        <a href="cancel_appointment.php?id=<?= $appointment['id'] ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Yakin batalkan janji ini?')">
                                            Batalkan
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>