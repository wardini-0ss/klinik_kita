<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

// Ambil jadwal semua dokter
$schedules = $conn->query("
    SELECT d.name, d.specialization, s.day, s.start_time, s.end_time
    FROM schedules s
    JOIN doctors d ON s.doctor_id = d.id
    ORDER BY d.name, FIELD(s.day, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu')
");
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Jadwal Praktek Dokter</h3>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Dokter</th>
                            <th>Spesialisasi</th>
                            <th>Hari</th>
                            <th>Jam Praktek</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($schedule = $schedules->fetch_assoc()): ?>
                            <tr>
                                <td>Dr. <?= htmlspecialchars($schedule['name']) ?></td>
                                <td><?= $schedule['specialization'] ?></td>
                                <td><?= $schedule['day'] ?></td>
                                <td><?= date('H:i', strtotime($schedule['start_time'])) ?> - <?= date('H:i', strtotime($schedule['end_time'])) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>