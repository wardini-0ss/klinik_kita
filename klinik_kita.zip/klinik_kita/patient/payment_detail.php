<?php
include '../includes/auth.php';
include '../config/database.php';
if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: billing.php");
    exit();
}

$payment_id = $_GET['id'];
$patient_id = $_SESSION['user_id'];

// Verifikasi bahwa pembayaran milik pasien ini
$query = "SELECT p.*, a.appointment_date, d.name AS doctor_name 
          FROM payments p
          JOIN appointments a ON p.appointment_id = a.id
          JOIN doctors d ON a.doctor_id = d.id
          WHERE p.id = ? AND a.patient_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $payment_id, $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    header("Location: billing.php");
    exit();
}

$payment = $result->fetch_assoc();

// Ambil item pembayaran
$items_query = "SELECT pi.*, s.name AS service_name 
                FROM payment_items pi
                LEFT JOIN services s ON pi.service_id = s.id
                WHERE pi.payment_id = ?";
$items_stmt = $conn->prepare($items_query);
$items_stmt->bind_param("i", $payment_id);
$items_stmt->execute();
$items = $items_stmt->get_result();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="row">
        <div class="col-md-9">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4>Detail Pembayaran</h4>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5>Informasi Pembayaran</h5>
                            <table class="table table-sm">
                                <tr>
                                    <th>No. Invoice</th>
                                    <td>INV-<?= str_pad($payment['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal Konsultasi</th>
                                    <td><?= date('d F Y', strtotime($payment['appointment_date'])) ?></td>
                                </tr>
                                <tr>
                                    <th>Dokter</th>
                                    <td><?= htmlspecialchars($payment['doctor_name']) ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h5>Status Pembayaran</h5>
                            <table class="table table-sm">
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <span class="badge bg-<?= 
                                            $payment['status'] == 'paid' ? 'success' : 
                                            ($payment['status'] == 'pending' ? 'warning' : 'danger') 
                                        ?>">
                                            <?= ucfirst($payment['status']) ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Total</th>
                                    <td>Rp <?= number_format($payment['amount'], 0, ',', '.') ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal Pembayaran</th>
                                    <td><?= $payment['payment_date'] ? date('d F Y H:i', strtotime($payment['payment_date'])) : '-' ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    
                                <?php 
                                $counter = 1;
                                while ($item = $items->fetch_assoc()): 
                                ?>
                                    <tr>
                                        <td><?= $counter++ ?></td>
                                        <td><?= htmlspecialchars($item['service_name'] ?: $item['description']) ?></td>
                                        <td>Rp <?= number_format($item['price'], 0, ',', '.') ?></td>
                                        <td><?= $item['quantity'] ?></td>
                                        <td>Rp <?= number_format($item['price'] * $item['quantity'], 0, ',', '.') ?></td>
                                    </tr>
                                <?php endwhile; ?>
                                <tr class="table-active">
                                    <td colspan="4" class="text-end"><strong>Total</strong></td>
                                    <td><strong>Rp <?= number_format($payment['amount'], 0, ',', '.') ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="billing.php" class="btn btn-secondary">Kembali</a>
                       
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>