<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya pasien yang bisa akses
if ($_SESSION['role'] != 'patient') {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: billing.php");
    exit();
}

$payment_id = $_GET['id'];
$patient_id = $_SESSION['user_id'];

// Verifikasi bahwa pembayaran tersebut milik pasien yang login
$check_stmt = $conn->prepare("
    SELECT p.id FROM payments p
    JOIN appointments a ON p.appointment_id = a.id
    WHERE p.id = ? AND a.patient_id = ? AND p.status = 'pending'
");
$check_stmt->bind_param("ii", $payment_id, $patient_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    $_SESSION['error_message'] = "Pembayaran tidak ditemukan atau sudah diproses";
    header("Location: billing.php");
    exit();
}

// Dapatkan detail pembayaran
$stmt = $conn->prepare("
    SELECT p.*, a.appointment_date, d.name as doctor_name, 
           d.specialization, pt.name as patient_name
    FROM payments p
    JOIN appointments a ON p.appointment_id = a.id
    JOIN doctors d ON a.doctor_id = d.id
    JOIN patients pt ON a.patient_id = pt.id
    WHERE p.id = ?
");
$stmt->bind_param("i", $payment_id);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();

// Proses pembayaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_method = $_POST['payment_method'];
    
    // Upload bukti pembayaran jika ada
    $payment_proof = null;
    if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = '../uploads/payments/';
        $file_name = time() . '_' . basename($_FILES['payment_proof']['name']);
        $target_file = $upload_dir . $file_name;
        
        // Validasi file
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'pdf'];
        
        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES['payment_proof']['tmp_name'], $target_file)) {
                $payment_proof = $file_name;
            }
        }
    }
    
    // Update status pembayaran
    $update_stmt = $conn->prepare("
        UPDATE payments 
        SET status = 'paid', 
            payment_method = ?,
            payment_proof = ?,
            payment_date = NOW()
        WHERE id = ?
    ");
    $update_stmt->bind_param("ssi", $payment_method, $payment_proof, $payment_id);
    
    if ($update_stmt->execute()) {
        $_SESSION['success_message'] = "Pembayaran berhasil diproses";
        header("Location: payment_detail.php?id=" . $payment_id);
        exit();
    } else {
        $_SESSION['error_message'] = "Gagal memproses pembayaran";
        header("Location: payment.php?id=" . $payment_id);
        exit();
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4>Proses Pembayaran</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($_SESSION['error_message'])): ?>
                        <div class="alert alert-danger">
                            <?= $_SESSION['error_message'] ?>
                            <?php unset($_SESSION['error_message']); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-4">
                        <h5>Detail Tagihan</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>No. Tagihan:</strong> INV-<?= str_pad($payment['id'], 5, '0', STR_PAD_LEFT) ?>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>Tanggal Konsultasi:</strong> <?= date('d F Y', strtotime($payment['appointment_date'])) ?>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>Dokter:</strong> <?= htmlspecialchars($payment['doctor_name']) ?>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">
                                        <strong>Spesialisasi:</strong> <?= htmlspecialchars($payment['specialization']) ?>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>Jumlah:</strong> Rp <?= number_format($payment['amount'], 0, ',', '.') ?>
                                    </li>
                                    <li class="list-group-item">
                                        <strong>Status:</strong> 
                                        <span class="badge bg-warning"><?= ucfirst($payment['status']) ?></span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="payment_method" class="form-label">Metode Pembayaran</label>
                            <select class="form-select" id="payment_method" name="payment_method" required>
                                <option value="">Pilih metode pembayaran...</option>
                                <option value="transfer_bank">Transfer Bank</option>
                                <option value="kartu_kredit">Kartu Kredit</option>
                                <option value="e_wallet">E-Wallet (OVO/Gopay/Dana)</option>
                                <option value="tunai">Tunai di Tempat</option>
                            </select>
                        </div>
                        
                        <div class="mb-3" id="proofSection">
                            <label for="payment_proof" class="form-label">Bukti Pembayaran</label>
                            <input type="file" class="form-control" id="payment_proof" name="payment_proof">
                            <small class="text-muted">Upload bukti transfer/screenshot pembayaran (format: JPG, PNG, PDF)</small>
                        </div>
                        
                        <div class="alert alert-info">
                            <h6>Instruksi Pembayaran:</h6>
                            <ul>
                                <li>Transfer Bank: BCA 1234567890 a.n Klinik Sehat</li>
                                <li>E-Wallet: 081234567890 a.n Klinik Sehat</li>
                                <li>Pembayaran tunai bisa dilakukan saat check-in</li>
                            </ul>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success btn-lg">
                                <i class="fas fa-check-circle"></i> Konfirmasi Pembayaran
                            </button>
                            <a href="billing.php" class="btn btn-outline-secondary">
                                <i class="fas fa-arrow-left"></i> Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Sembunyikan field bukti pembayaran jika metode tunai dipilih
document.getElementById('payment_method').addEventListener('change', function() {
    const proofSection = document.getElementById('proofSection');
    if (this.value === 'tunai') {
        proofSection.style.display = 'none';
    } else {
        proofSection.style.display = 'block';
    }
});
</script>

<?php include '../includes/footer.php'; ?>