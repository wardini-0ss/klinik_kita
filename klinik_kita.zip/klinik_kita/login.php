<?php
include 'config/database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $table = '';
    switch ($role) {
        case 'patient': $table = 'patients'; break;
        case 'doctor': $table = 'doctors'; break;
        case 'receptionist': $table = 'receptionists'; break;
        case 'admin': $table = 'admins'; break;
    }

    $stmt = $conn->prepare("SELECT * FROM $table WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $role;
            $_SESSION['name'] = $user['name'];
            header("Location: $role/dashboard.php");
            exit();
        } else {
            $error = "Email atau password salah";
        }
    } else {
        $error = "Email atau password salah";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Klinik Sehat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c7be5;
            --secondary: #6c757d;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #00d97e;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #e4f0fb 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        
        .login-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .login-card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            background: white;
        }
        
        .login-left {
            background: url('assets/images/medical-bg.jpg') center/cover no-repeat;
            color: white;
            position: relative;
            padding: 3rem;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .login-left::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(44, 123, 229, 0.85);
            z-index: 0;
        }
        
        .login-left-content {
            position: relative;
            z-index: 1;
        }
        
        .login-right {
            padding: 3rem;
        }
        
        .logo {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
        }
        
        .logo i {
            margin-right: 10px;
        }
        
        .form-control {
            padding: 12px 15px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.25rem rgba(44, 123, 229, 0.25);
        }
        
        .btn-login {
            background-color: var(--primary);
            border: none;
            padding: 12px;
            border-radius: 8px;
            font-weight: 500;
            width: 100%;
            transition: all 0.3s;
        }
        
        .btn-login:hover {
            background-color: #1c6bd6;
            transform: translateY(-2px);
        }
        
        .role-icon {
            font-size: 1.2rem;
            margin-right: 8px;
        }
        
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            color: var(--secondary);
            margin: 20px 0;
        }
        
        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .divider::before {
            margin-right: 10px;
        }
        
        .divider::after {
            margin-left: 10px;
        }
        
        .input-group-text {
            background-color: #e9f2fd;
            border-color: #e0e0e0;
        }
        
        .feature-list {
            list-style: none;
            padding: 0;
        }
        
        .feature-list li {
            margin-bottom: 15px;
            padding-left: 30px;
            position: relative;
        }
        
        .feature-list li::before {
            content: "\f00c";
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            position: absolute;
            left: 0;
            color: var(--success);
        }
        
        @media (max-width: 991.98px) {
            .login-left {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container login-container">
        <div class="row g-0 login-card">
            <!-- Left Side - Branding -->
            <div class="col-lg-6 login-left">
                <div class="login-left-content">
                    <h1 class="display-5 fw-bold mb-4">Selamat Datang di Klinik Sehat</h1>
                    <p class="lead mb-5">Sistem Informasi Kesehatan Terintegrasi</p>
                    
                    <ul class="feature-list">
                        <li class="mb-3">Akses cepat ke semua fitur klinik</li>
                        <li class="mb-3">Antarmuka yang ramah pengguna</li>
                        <li class="mb-3">Keamanan data pasien terjamin</li>
                        <li>Dukungan multi-peran (Pasien, Dokter, Staff)</li>
                    </ul>
                </div>
            </div>
            
            <!-- Right Side - Login Form -->
            <div class="col-lg-6 login-right">
                <div class="logo">
                    <i class="fas fa-clinic-medical"></i>
                    <span>Klinik Sehat</span>
                </div>
                
                <h2 class="mb-4 fw-bold">Masuk ke Akun Anda</h2>
                <p class="text-muted mb-4">Silakan masukkan detail login Anda</p>
                
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="mb-4">
                        <label class="form-label fw-bold">Masuk Sebagai</label>
                        <select name="role" class="form-select form-select-lg" required>
                            <option value="" selected disabled>Pilih peran Anda</option>
                            <option value="patient"><i class="fas fa-user role-icon"></i> Pasien</option>
                            <option value="doctor"><i class="fas fa-user-md role-icon"></i> Dokter</option>
                            <option value="receptionist"><i class="fas fa-headset role-icon"></i> Resepsionis</option>
                            <option value="admin"><i class="fas fa-cog role-icon"></i> Administrator</option>
                        </select>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold">Alamat Email</label>
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" name="email" class="form-control form-control-lg" placeholder="contoh@email.com" required>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="form-label fw-bold">Password</label>
                        <div class="input-group mb-3">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" name="password" class="form-control form-control-lg" placeholder="Masukkan password" required>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="d-grid mb-3">
                        <button type="submit" class="btn btn-login btn-lg">
                            <i class="fas fa-sign-in-alt me-2"></i> Masuk
                        </button>
                    </div>
                    
                    <div class="text-end mb-4">
                        <a href="forgot-password.php" class="text-decoration-none">Lupa password?</a>
                    </div>
                </form>
                
                <div class="divider">ATAU</div>
                
                <div class="text-center">
                    <p class="mb-0">Pasien baru? <a href="patient/register.php" class="fw-bold text-decoration-none">Daftar akun baru</a></p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.querySelector('input[name="password"]');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });

        // Format select options with icons
        document.querySelectorAll('select option').forEach(option => {
            if (option.value) {
                option.innerHTML = `<i class="fas ${getRoleIcon(option.value)} role-icon"></i> ${option.text}`;
            }
        });
        
        function getRoleIcon(role) {
            const icons = {
                'patient': 'fa-user',
                'doctor': 'fa-user-md',
                'receptionist': 'fa-headset',
                'admin': 'fa-cog'
            };
            return icons[role] || 'fa-user';
        }
    </script>
</body>
</html>