<?php
include 'config/database.php';

$name = "Rina";
$email = "resepsionismia@gmail.com";
$password = "resepsionis123";

// Enkripsi password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Masukkan ke database
$stmt = $conn->prepare("INSERT INTO receptionists (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $hashed_password);

if ($stmt->execute()) {
    echo "Akun resepsionis berhasil dibuat!";
} else {
    echo "Gagal membuat akun resepsionis: " . $stmt->error;
}
?>
