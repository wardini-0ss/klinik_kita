<?php
include 'config/database.php';

$name = "Dr. Pariska";
$email = "doctor@gmail.com";
$password = "dokter123";

// Enkripsi password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Masukkan ke database
$stmt = $conn->prepare("INSERT INTO doctors (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $hashed_password);

if ($stmt->execute()) {
    echo "Akun dokter berhasil dibuat!";
} else {
    echo "Gagal membuat akun dokter: " . $stmt->error;
}
?>
