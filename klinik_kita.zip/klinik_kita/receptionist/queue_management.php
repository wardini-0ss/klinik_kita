<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'receptionist') {
    header("Location: ../login.php");
    exit();
}

// Proses perubahan status
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $appointment_id = $_POST['appointment_id'];
    $action = $_POST['action'];
    
    $valid_status = ['pending', 'confirmed', 'completed', 'canceled'];
    if (in_array($action, $valid_status)) {
        $stmt = $conn->prepare("UPDATE appointments SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $action, $appointment_id);
        $stmt->execute();
    }
}

// Ambil antrian hari ini
$today = date('Y-m-d');
$queue = $conn->query("
    SELECT a.id, a.patient_name, d.name as doctor_name, 
           a.appointment_date, a.status
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    WHERE a.appointment_date = '$today'
    ORDER BY a.status, a.appointment_date
");
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Manajemen Antrian</h3>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Pasien</th>
                            <th>Dokter</th>
                            <th>Waktu</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $counter = 1; while ($row = $queue->fetch_assoc()): ?>
                            <tr>
                                <td><?= $counter++ ?></td>
                                <td><?= htmlspecialchars($row['patient_name']) ?></td>
                                <td>Dr. <?= htmlspecialchars($row['doctor_name']) ?></td>
                                <td><?= date('H:i', strtotime($row['appointment_date'])) ?></td>
                                <td>
                                    <span class="badge bg-<?= getStatusColor($row['status']) ?>">
                                        <?= ucfirst($row['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" style="display:inline">
                                        <input type="hidden" name="appointment_id" value="<?= $row['id'] ?>">
                                        <?php if ($row['status'] == 'pending'): ?>
                                            <button type="submit" name="action" value="confirmed" class="btn btn-sm btn-success">Konfirmasi</button>
                                            <button type="submit" name="action" value="canceled" class="btn btn-sm btn-danger">Batalkan</button>
                                        <?php elseif ($row['status'] == 'confirmed'): ?>
                                            <button type="submit" name="action" value="completed" class="btn btn-sm btn-primary">Selesai</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>