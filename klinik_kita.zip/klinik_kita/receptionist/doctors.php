<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

// Query dokter
$query = "SELECT * FROM doctors ORDER BY name";
$result = $conn->query($query);
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manajemen Data Dokter</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="doctors_create.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus"></i> Tambah Dokter
                    </a>
                </div>
            </div>

            <!-- Tabel Dokter -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="doctorsTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama</th>
                                    <th>Spesialisasi</th>
                                    <th>Email</th>
                                    <th>Telepon</th>
                                    <th>Lisensi</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 1;
                                while ($row = $result->fetch_assoc()):
                                ?>
                                <tr>
                                    <td><?= $counter++ ?></td>
                                    <td>Dr. <?= htmlspecialchars($row['name']) ?></td>
                                    <td><?= htmlspecialchars($row['specialization']) ?></td>
                                    <td><?= htmlspecialchars($row['email']) ?></td>
                                    <td><?= htmlspecialchars($row['phone']) ?></td>
                                    <td><?= htmlspecialchars($row['license_number']) ?></td>
                                    <td>
                                        <a href="doctors_detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="doctors_edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="doctors_delete.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" title="Hapus" onclick="return confirm('Yakin ingin menghapus dokter ini?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>