<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

// Default filter: bulan ini
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$report_type = $_GET['report_type'] ?? 'appointments';
$detail_level = $_GET['detail_level'] ?? 'summary'; // 'summary' or 'detailed'

// Query berdasarkan jenis laporan
if ($report_type == 'appointments') {
    if ($detail_level == 'detailed') {
        $query = "SELECT 
                    a.id,
                    p.name as patient_name,
                    d.name as doctor_name,
                    DATE(a.appointment_date) as date,
                    a.start_time,
                    a.end_time,
                    a.status,
                    a.notes,
                    a.created_at,
                    pm.amount as payment_amount,
                    pm.status as payment_status
                  FROM appointments a
                  JOIN patients p ON a.patient_id = p.id
                  JOIN doctors d ON a.doctor_id = d.id
                  LEFT JOIN payments pm ON pm.appointment_id = a.id
                  WHERE a.appointment_date BETWEEN ? AND ?
                  ORDER BY a.appointment_date, a.start_time";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $start_date, $end_date);
        $stmt->execute();
        $result = $stmt->get_result();
        $report_data = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $query = "SELECT 
                    DATE(a.appointment_date) as date,
                    COUNT(*) as total,
                    SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) as completed,
                    SUM(CASE WHEN a.status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                    SUM(CASE WHEN a.status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                    SUM(CASE WHEN a.status = 'pending' THEN 1 ELSE 0 END) as pending
                  FROM appointments a
                  WHERE a.appointment_date BETWEEN ? AND ?
                  GROUP BY DATE(a.appointment_date)
                  ORDER BY a.appointment_date";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $start_date, $end_date);
        $stmt->execute();
        $result = $stmt->get_result();
        $report_data = $result->fetch_all(MYSQLI_ASSOC);
    }
} elseif ($report_type == 'payments') {
    // ... (keep your existing payments query)
} elseif ($report_type == 'patients') {
    // ... (keep your existing patients query)
}
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Sistem Laporan</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <button class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                        <i class="fas fa-print"></i> Cetak Laporan
                    </button>
                </div>
            </div>

            <!-- Filter Laporan -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Jenis Laporan</label>
                            <select name="report_type" class="form-select" onchange="this.form.submit()">
                                <option value="appointments" <?= $report_type == 'appointments' ? 'selected' : '' ?>>Janji Temu</option>
                                <option value="payments" <?= $report_type == 'payments' ? 'selected' : '' ?>>Pembayaran</option>
                                <option value="patients" <?= $report_type == 'patients' ? 'selected' : '' ?>>Pasien Baru</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Detail Laporan</label>
                            <select name="detail_level" class="form-select" onchange="this.form.submit()">
                                <option value="summary" <?= $detail_level == 'summary' ? 'selected' : '' ?>>Ringkasan</option>
                                <option value="detailed" <?= $detail_level == 'detailed' ? 'selected' : '' ?>>Detail Lengkap</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Dari Tanggal</label>
                            <input type="date" name="start_date" class="form-control" value="<?= $start_date ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Sampai Tanggal</label>
                            <input type="date" name="end_date" class="form-control" value="<?= $end_date ?>">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-filter"></i> Filter
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Hasil Laporan -->
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">
                        Laporan <?= ucfirst($report_type) ?> 
                        (<?= date('d M Y', strtotime($start_date)) ?> - <?= date('d M Y', strtotime($end_date)) ?>)
                        <?php if ($report_type == 'appointments'): ?>
                        <span class="badge bg-secondary ms-2"><?= $detail_level == 'detailed' ? 'Detail Lengkap' : 'Ringkasan' ?></span>
                        <?php endif; ?>
                    </h5>
                    
                    <div class="table-responsive">
                        <?php if ($report_type == 'appointments' && $detail_level == 'detailed'): ?>
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Waktu</th>
                                    <th>Pasien</th>
                                    <th>Dokter</th>
                                    <th>Status</th>
                                    <th>Pembayaran</th>
                                    <th>Catatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($report_data as $index => $row): ?>
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= date('d M Y', strtotime($row['date'])) ?></td>
                                    <td><?= date('H:i', strtotime($row['start_time'])) ?> - <?= date('H:i', strtotime($row['end_time'])) ?></td>
                                    <td><?= htmlspecialchars($row['patient_name']) ?></td>
                                    <td>Dr. <?= htmlspecialchars($row['doctor_name']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= 
                                            $row['status'] == 'completed' ? 'success' : 
                                            ($row['status'] == 'cancelled' ? 'danger' : 
                                            ($row['status'] == 'confirmed' ? 'primary' : 'warning')) 
                                        ?>">
                                            <?= ucfirst($row['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($row['payment_amount']): ?>
                                        Rp <?= number_format($row['payment_amount'], 0, ',', '.') ?>
                                        <span class="badge bg-<?= $row['payment_status'] == 'paid' ? 'success' : 'warning' ?> ms-1">
                                            <?= $row['payment_status'] ?>
                                        </span>
                                        <?php else: ?>
                                        <span class="text-muted">Belum dibayar</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= !empty($row['notes']) ? htmlspecialchars($row['notes']) : '-' ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($report_data)): ?>
                                <tr>
                                    <td colspan="8" class="text-center">Tidak ada data janji temu</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                        <?php elseif ($report_type == 'appointments'): ?>
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Total</th>
                                    <th>Selesai</th>
                                    <th>Dikonfirmasi</th>
                                    <th>Menunggu</th>
                                    <th>Dibatalkan</th>
                                    <th>% Selesai</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($report_data as $row): ?>
                                <tr>
                                    <td><?= date('d M Y', strtotime($row['date'])) ?></td>
                                    <td><?= $row['total'] ?></td>
                                    <td><?= $row['completed'] ?></td>
                                    <td><?= $row['confirmed'] ?></td>
                                    <td><?= $row['pending'] ?></td>
                                    <td><?= $row['cancelled'] ?></td>
                                    <td><?= $row['total'] > 0 ? round(($row['completed'] / $row['total']) * 100, 2) : 0 ?>%</td>
                                    <td>
                                        <a href="reports.php?report_type=appointments&detail_level=detailed&start_date=<?= $row['date'] ?>&end_date=<?= $row['date'] ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-list"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($report_data)): ?>
                                <tr>
                                    <td colspan="8" class="text-center">Tidak ada data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php elseif ($report_type == 'payments'): ?>
                        <!-- ... (keep your existing payments table) ... -->
                        <?php elseif ($report_type == 'patients'): ?>
                        <!-- ... (keep your existing patients table) ... -->
                        <?php endif; ?>
                    </div>
                    
                    <!-- Export Button -->
                    <div class="mt-4 text-end">
                        <a href="export_report.php?<?= http_build_query($_GET) ?>" class="btn btn-success">
                            <i class="fas fa-file-excel"></i> Export ke Excel
                        </a>
                    </div>
                    
                    <!-- Grafik -->
                    <?php if ($detail_level == 'summary'): ?>
                    <div class="mt-5">
                        <canvas id="reportChart" height="100"></canvas>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php if ($detail_level == 'summary'): ?>
<!-- Chart JS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
$(document).ready(function() {
    // ... (keep your existing chart code) ...
});
</script>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>