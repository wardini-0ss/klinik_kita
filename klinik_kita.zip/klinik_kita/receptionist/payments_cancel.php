<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST' || !isset($_POST['id']) || !is_numeric($_POST['id'])) {
    header("Location: payments.php");
    exit();
}

$payment_id = $_POST['id'];
$cancel_reason = $_POST['cancel_reason'];

$stmt = $conn->prepare("UPDATE payments SET status = 'cancelled', cancel_reason = ? WHERE id = ?");
$stmt->bind_param("si", $cancel_reason, $payment_id);

if ($stmt->execute()) {
    $_SESSION['success_message'] = "Pembayaran berhasil dibatalkan";
} else {
    $_SESSION['error_message'] = "Gagal membatalkan pembayaran";
}

header("Location: payments_detail.php?id=" . $payment_id);
exit();
?>