<?php
include '../config/database.php'; 
include '../includes/auth.php';
// Pastikan hanya resepsionis yang bisa akses
if ($_SESSION['role'] != 'receptionist') {
    header("Location: ../login.php");
    exit();
}

// Hitung statistik
$today = date('Y-m-d');
$tomorrow = date('Y-m-d', strtotime('+1 day'));
$current_month = date('Y-m');

// Query untuk statistik
$today_appointments = $conn->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = '$today'")->fetch_row()[0];
$confirmed_today = $conn->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = '$today' AND status = 'confirmed'")->fetch_row()[0];
$pending_today = $conn->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = '$today' AND status = 'pending'")->fetch_row()[0];
$tomorrow_appointments = $conn->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = '$tomorrow'")->fetch_row()[0];
$monthly_appointments = $conn->query("SELECT COUNT(*) FROM appointments WHERE DATE_FORMAT(appointment_date, '%Y-%m') = '$current_month'")->fetch_row()[0];
$total_patients = $conn->query("SELECT COUNT(*) FROM patients")->fetch_row()[0];
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
            <div class="position-sticky pt-3">
                <div class="text-center mb-4">
                    <img src="../assets/images/receptionist-avatar.jpg" alt="Avatar" class="rounded-circle" width="80">
                    <h5 class="mt-2"><?= htmlspecialchars($_SESSION['name']) ?></h5>
                    <small class="text-muted">Resepsionis</small>
                </div>
                
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="appointments.php">
                            <i class="fas fa-calendar-check me-2"></i>Manajemen Janji
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="patients.php">
                            <i class="fas fa-users me-2"></i>Data Pasien
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="doctors.php">
                            <i class="fas fa-user-md me-2"></i>Data Dokter
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="quick_registration.php">
                            <i class="fas fa-plus-circle me-2"></i>Pendaftaran Cepat
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payments.php">
                            <i class="fas fa-credit-card me-2"></i>Pembayaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-bar me-2"></i>Laporan
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard Resepsionis</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Hari Ini</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary">Bulan Ini</button>
                    </div>
                    <a href="new_appointment.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus"></i> Janji Baru
                    </a>
                </div>
            </div>

            <!-- Info Cards -->
            <div class="row mb-4">
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                        Janji Hari Ini</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $today_appointments ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-calendar-day fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                        Dikonfirmasi</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $confirmed_today ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                        Menunggu Konfirmasi</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $pending_today ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-clock fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-info shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                        Janji Besok</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $tomorrow_appointments ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-calendar-alt fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Content Row -->
            <div class="row">
                <!-- Antrian Hari Ini -->
                <div class="col-lg-8 mb-4">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Antrian Hari Ini (<?= date('d F Y') ?>)</h6>
                            <div class="dropdown no-arrow">
                                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" 
                                   data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="dropdownMenuLink">
                                    <li><a class="dropdown-item" href="appointments.php?filter=today">Lihat Semua</a></li>
                                    <li><a class="dropdown-item" href="patient_print.php" onclick="printTodayQueue()">Cetak Antrian</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover" id="todayQueueTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Pasien</th>
                                            <th>Dokter</th>
                                            <th>Waktu</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $result = $conn->query("
                                            SELECT a.id, p.name as patient_name, d.name as doctor_name, 
                                                   a.appointment_date, a.start_time, a.end_time, a.status 
                                            FROM appointments a
                                            JOIN patients p ON a.patient_id = p.id
                                            JOIN doctors d ON a.doctor_id = d.id
                                            WHERE a.appointment_date = '$today'
                                            ORDER BY a.start_time ASC
                                        ");
                                        
                                        $counter = 1;
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<tr>
                                                <td>$counter</td>
                                                <td>{$row['patient_name']}</td>
                                                <td>Dr. {$row['doctor_name']}</td>
                                                <td>" . date('H:i', strtotime($row['start_time'])) . " - " . date('H:i', strtotime($row['end_time'])) . "</td>
                                                <td>
                                                    <span class='badge bg-" . getStatusColor($row['status']) . "'>
                                                        " . ucfirst($row['status']) . "
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href='appointment_detail.php?id={$row['id']}' class='btn btn-sm btn-circle btn-primary' title='Detail'>
                                                        <i class='fas fa-eye'></i>
                                                    </a>
                                                    <a href='edit_appointment.php?id={$row['id']}' class='btn btn-sm btn-circle btn-warning' title='Edit'>
                                                        <i class='fas fa-edit'></i>
                                                    </a>
                                                </td>
                                            </tr>";
                                            $counter++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions & Calendar -->
                <div class="col-lg-4 mb-4">
                    <!-- Quick Actions -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Aksi Cepat</h6>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="new_appointment.php" class="btn btn-primary mb-2">
                                    <i class="fas fa-plus me-1"></i> Janji Baru
                                </a>
                                <a href="quick_registration.php" class="btn btn-success mb-2">
                                    <i class="fas fa-user-plus me-1"></i> Pasien Baru
                                </a>
                                <a href="payments.php" class="btn btn-info mb-2">
                                    <i class="fas fa-credit-card me-1"></i> Pembayaran
                                </a>
                                <button class="btn btn-warning mb-2" data-bs-toggle="modal" data-bs-target="#checkInModal">
                                    <i class="fas fa-check-circle me-1"></i> Check-In Pasien
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Calendar -->
                    <div class="card shadow">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Kalender</h6>
                        </div>
                        <div class="card-body">
                            <div id="miniCalendar"></div>
                            <div class="mt-3">
                                <small class="text-primary"><i class="fas fa-circle"></i> Hari Ini</small><br>
                                <small class="text-success"><i class="fas fa-circle"></i> Ada Janji</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Patients -->
            <div class="row">
                <div class="col-12">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Pasien Terbaru</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="recentPatients" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Telepon</th>
                                            <th>Tanggal Lahir</th>
                                            <th>Jenis Kelamin</th>
                                            <th>Terdaftar</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $result = $conn->query("
                                            SELECT * FROM patients 
                                            ORDER BY created_at DESC 
                                            LIMIT 5
                                        ");
                                        
                                        $counter = 1;
                                        while ($row = $result->fetch_assoc()) {
                                            echo "<tr>
                                                <td>$counter</td>
                                                <td>{$row['name']}</td>
                                                <td>{$row['phone']}</td>
                                                <td>" . ($row['birth_date'] ? date('d/m/Y', strtotime($row['birth_date'])) : '-') . "</td>
                                                <td>" . getGenderLabel($row['gender']) . "</td>
                                                <td>" . date('d/m/Y H:i', strtotime($row['created_at'])) . "</td>
                                                <td>
                                                    <a href='patient_detail.php?id={$row['id']}' class='btn btn-sm btn-primary'>
                                                        <i class='fas fa-eye'></i> Detail
                                                    </a>
                                                </td>
                                            </tr>";
                                            $counter++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Check-In Modal -->
<div class="modal fade" id="checkInModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Check-In Pasien</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="checkInForm">
                    <div class="mb-3">
                        <label class="form-label">Cari Pasien</label>
                        <select class="form-select select2" id="patientSelect" required>
                            <option value="">Pilih Pasien</option>
                            <?php
                            $result = $conn->query("SELECT id, name FROM patients ORDER BY name");
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='{$row['id']}'>{$row['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Janji Temu</label>
                        <select class="form-select" id="appointmentSelect" required>
                            <option value="">Pilih Janji</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-primary" id="confirmCheckIn">Check-In</button>
            </div>
        </div>
    </div>
</div>

<?php 
function getStatusColor($status) {
    switch ($status) {
        case 'completed': return 'success';
        case 'confirmed': return 'primary';
        case 'cancelled': return 'danger';
        case 'pending': return 'warning';
        case 'checked_in': return 'info';
        default: return 'secondary';
    }
}

function getGenderLabel($gender) {
    switch ($gender) {
        case 'male': return 'Laki-laki';
        case 'female': return 'Perempuan';
        case 'other': return 'Lainnya';
        default: return '-';
    }
}

include '../includes/footer.php'; 
?>

<!-- CSS Tambahan -->
<style>
    .sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        z-index: 100;
        padding: 48px 0 0;
        box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
    }
    
    .nav-link {
        font-weight: 500;
        color: #333;
        padding: 0.75rem 1rem;
        border-radius: 0.25rem;
    }
    
    .nav-link:hover {
        background-color: rgba(13, 110, 253, 0.1);
        color: #0d6efd;
    }
    
    .nav-link.active {
        color: #0d6efd;
        background-color: rgba(13, 110, 253, 0.1);
    }
    
    .card {
        transition: transform 0.2s;
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .card:hover {
        transform: translateY(-5px);
    }
    
    .border-left-primary {
        border-left: 0.25rem solid #4e73df !important;
    }
    
    .border-left-success {
        border-left: 0.25rem solid #1cc88a !important;
    }
    
    .border-left-info {
        border-left: 0.25rem solid #36b9cc !important;
    }
    
    .border-left-warning {
        border-left: 0.25rem solid #f6c23e !important;
    }
    
    main {
        margin-left: 280px;
        padding-top: 1rem;
    }
    
    @media (max-width: 768px) {
        .sidebar {
            width: 100%;
            height: auto;
            position: relative;
        }
        main {
            margin-left: 0;
        }
    }
</style>

<!-- JavaScript Tambahan -->
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
    // Inisialisasi mini calendar
    var calendarEl = document.getElementById('miniCalendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: '',
            center: 'title',
            right: 'today prev,next'
        },
        height: 300,
        events: {
            url: 'get_appointments_for_calendar.php',
            method: 'GET',
            failure: function() {
                alert('Gagal memuat data kalender');
            }
        },
        dateClick: function(info) {
            window.location.href = 'appointments.php?date=' + info.dateStr;
        }
    });
    calendar.render();

    // Inisialisasi Select2
    $('.select2').select2({
        width: '100%',
        placeholder: 'Pilih Pasien'
    });

    // Load appointments ketika pasien dipilih
    $('#patientSelect').change(function() {
        var patientId = $(this).val();
        if (patientId) {
            $.ajax({
                url: 'get_patient_appointments.php',
                type: 'GET',
                data: { patient_id: patientId, upcoming_only: true },
                success: function(response) {
                    $('#appointmentSelect').html(response);
                }
            });
        } else {
            $('#appointmentSelect').html('<option value="">Pilih Janji</option>');
        }
    });

    // Proses check-in
    $('#confirmCheckIn').click(function() {
        var appointmentId = $('#appointmentSelect').val();
        if (appointmentId) {
            $.ajax({
                url: 'process_checkin.php',
                type: 'POST',
                data: { appointment_id: appointmentId },
                success: function(response) {
                    if (response.success) {
                        alert('Check-in berhasil');
                        location.reload();
                    } else {
                        alert('Gagal check-in: ' + response.message);
                    }
                },
                dataType: 'json'
            });
        } else {
            alert('Pilih janji temu terlebih dahulu');
        }
    });
});

function printTodayQueue() {
    var printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Antrian Hari Ini</title>');
    printWindow.document.write('<style>body{font-family:Arial;margin:20px;}');
    printWindow.document.write('table{width:100%;border-collapse:collapse;}');
    printWindow.document.write('th,td{padding:8px;border:1px solid #ddd;text-align:left;}');
    printWindow.document.write('th{background-color:#f2f2f2;}</style></head><body>');
    printWindow.document.write('<h2>Antrian Hari Ini - <?= date("d F Y") ?></h2>');
    printWindow.document.write(document.getElementById('todayQueueTable').outerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
}
</script>