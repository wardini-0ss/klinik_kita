<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "ID pasien tidak valid.";
    header("Location: patients.php");
    exit();
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error'] = "Pasien tidak ditemukan.";
    header("Location: patients.php");
    exit();
}

$patient = $result->fetch_assoc();
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Detail Pasien</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="patients.php" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>

            <div class="card shadow">
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr><th>Nama</th><td><?= htmlspecialchars($patient['name']) ?></td></tr>
                        <tr><th>Email</th><td><?= htmlspecialchars($patient['email']) ?></td></tr>
                        <tr><th>Telepon</th><td><?= htmlspecialchars($patient['phone']) ?></td></tr>
                        <tr><th>Tanggal Lahir</th><td><?= $patient['birth_date'] ? date('d/m/Y', strtotime($patient['birth_date'])) : '-' ?></td></tr>
                        <tr><th>Jenis Kelamin</th><td><?= getGenderLabel($patient['gender']) ?></td></tr>
                        <tr><th>Alamat</th><td><?= nl2br(htmlspecialchars($patient['address'])) ?></td></tr>
                        <tr><th>Terdaftar Pada</th><td><?= date('d/m/Y H:i', strtotime($patient['created_at'])) ?></td></tr>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>