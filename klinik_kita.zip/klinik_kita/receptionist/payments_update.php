<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST' || !isset($_POST['id']) || !is_numeric($_POST['id'])) {
    header("Location: payments.php");
    exit();
}

$payment_id = $_POST['id'];
$amount = $_POST['amount'];

// Validasi jumlah
if ($amount < 10000) {
    $_SESSION['error_message'] = "Jumlah pembayaran minimal Rp 10.000";
    header("Location: payments_detail.php?id=" . $payment_id);
    exit();
}

$stmt = $conn->prepare("UPDATE payments SET amount = ? WHERE id = ?");
$stmt->bind_param("di", $amount, $payment_id);

if ($stmt->execute()) {
    $_SESSION['success_message'] = "Jumlah pembayaran berhasil diperbarui";
} else {
    $_SESSION['error_message'] = "Gagal memperbarui jumlah pembayaran";
}

header("Location: payments_detail.php?id=" . $payment_id);
exit();
?>