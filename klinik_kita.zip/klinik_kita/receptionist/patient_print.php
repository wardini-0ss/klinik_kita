<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: patients.php");
    exit();
}

$patient_id = intval($_GET['id']);

// Query untuk mendapatkan detail pasien
$query = "SELECT 
            p.*,
            COUNT(a.id) as total_appointments
          FROM patients p
          LEFT JOIN appointments a ON p.id = a.patient_id
          WHERE p.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: patients.php");
    exit();
}

$patient = $result->fetch_assoc();

// Query untuk mendapatkan 5 janji terakhir
$appointments_query = "SELECT 
                        a.appointment_date,
                        a.start_time,
                        a.end_time,
                        a.status,
                        d.name as doctor_name,
                        d.specialization
                      FROM appointments a
                      JOIN doctors d ON a.doctor_id = d.id
                      WHERE a.patient_id = ?
                      ORDER BY a.appointment_date DESC
                      LIMIT 5";
$appointments_stmt = $conn->prepare($appointments_query);
$appointments_stmt->bind_param("i", $patient_id);
$appointments_stmt->execute();
$appointments_result = $appointments_stmt->get_result();

// Fungsi helper untuk format tanggal dan waktu
function formatDate($date) {
    return $date ? date('d F Y', strtotime($date)) : '-';
}

function formatTime($time) {
    return $time ? date('H:i', strtotime($time)) : '-';
}

function getGenderLabel($gender) {
    return $gender == 'male' ? 'Laki-laki' : 'Perempuan';
}

// Set header untuk PDF
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="Data_Pasien_' . $patient_id . '.pdf"');
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Data Pasien</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12pt;
            line-height: 1.5;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
        }
        .clinic-name {
            font-size: 16pt;
            font-weight: bold;
        }
        .patient-title {
            font-size: 14pt;
            margin-top: 10px;
        }
        .section {
            margin-bottom: 15px;
        }
        .section-title {
            font-weight: bold;
            border-bottom: 1px solid #333;
            margin-bottom: 5px;
            padding-bottom: 3px;
        }
        .info-table {
            width: 100%;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 5px 0;
            vertical-align: top;
        }
        .info-table td:first-child {
            width: 30%;
            font-weight: bold;
        }
        .appointments-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .appointments-table th, 
        .appointments-table td {
            border: 1px solid #ddd;
            padding: 5px;
            text-align: left;
        }
        .appointments-table th {
            background-color: #f2f2f2;
        }
        .footer {
            margin-top: 30px;
            text-align: right;
            font-size: 10pt;
            border-top: 1px solid #333;
            padding-top: 5px;
        }
        .page-break {
            page-break-after: always;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="clinic-name">KLINIK SEHAT BAHAGIA</div>
        <div>Jl. Kesehatan No. 123, Jakarta</div>
        <div>Telp: (021) 555-1234 | Email: info@kliniksehatbahagia.com</div>
        <div class="patient-title">DATA PASIEN</div>
    </div>

    <div class="section">
        <div class="section-title">Informasi Pribadi</div>
        <table class="info-table">
            <tr>
                <td>ID Pasien</td>
                <td>: <?= $patient_id ?></td>
            </tr>
            <tr>
                <td>Nama Lengkap</td>
                <td>: <?= htmlspecialchars($patient['name']) ?></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>: <?= getGenderLabel($patient['gender']) ?></td>
            </tr>
            <tr>
                <td>Tanggal Lahir</td>
                <td>: <?= formatDate($patient['birth_date']) ?></td>
            </tr>
            <tr>
                <td>No. Telepon</td>
                <td>: <?= htmlspecialchars($patient['phone']) ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td>: <?= htmlspecialchars($patient['email']) ?></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td>: <?= nl2br(htmlspecialchars($patient['address'])) ?></td>
            </tr>
        </table>
    </div>

    <div class="section">
        <div class="section-title">Informasi Medis</div>
        <table class="info-table">
            <tr>
                <td>Golongan Darah</td>
                <td>: <?= isset($patient['blood_type']) ? htmlspecialchars($patient['blood_type']) : '-' ?></td>
            </tr>
            <tr>
                <td>Alergi</td>
                <td>: <?= isset($patient['allergies']) ? nl2br(htmlspecialchars($patient['allergies'])) : '-' ?></td>
            </tr>
            <tr>
                <td>Catatan Medis</td>
                <td>: <?= isset($patient['medical_notes']) ? nl2br(htmlspecialchars($patient['medical_notes'])) : '-' ?></td>
            </tr>
        </table>
    </div>

    <div class="section">
        <div class="section-title">Informasi Akun</div>
        <table class="info-table">
            <tr>
                <td>Total Janji Temu</td>
                <td>: <?= $patient['total_appointments'] ?></td>
            </tr>
            <tr>
                <td>Terdaftar Sejak</td>
                <td>: <?= formatDate($patient['created_at']) ?></td>
            </tr>
            <tr>
                <td>Terakhir Diupdate</td>
                <td>: <?= isset($patient['updated_at']) ? formatDate($patient['updated_at']) : '-' ?></td>
            </tr>
        </table>
    </div>

    <?php if ($appointments_result->num_rows > 0): ?>
    <div class="section">
        <div class="section-title">5 Janji Terakhir</div>
        <table class="appointments-table">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Waktu</th>
                    <th>Dokter</th>
                    <th>Spesialisasi</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($appointment = $appointments_result->fetch_assoc()): ?>
                <tr>
                    <td><?= formatDate($appointment['appointment_date']) ?></td>
                    <td><?= formatTime($appointment['start_time']) ?> - <?= formatTime($appointment['end_time']) ?></td>
                    <td>Dr. <?= htmlspecialchars($appointment['doctor_name']) ?></td>
                    <td><?= htmlspecialchars($appointment['specialization']) ?></td>
                    <td><?= ucfirst($appointment['status']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <div class="footer">
        Dicetak pada: <?= date('d F Y H:i:s') ?> oleh <?= $_SESSION['name'] ?>
    </div>
</body>
</html>
