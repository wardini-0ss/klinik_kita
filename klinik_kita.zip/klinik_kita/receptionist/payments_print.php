<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: payments.php");
    exit();
}

$payment_id = $_GET['id'];

// Query untuk mendapatkan detail pembayaran
$stmt = $conn->prepare("
    SELECT p.*, 
           a.appointment_date, a.complaint,
           pt.name as patient_name, pt.phone as patient_phone, pt.email as patient_email, pt.address as patient_address,
           d.name as doctor_name, d.specialization
    FROM payments p
    JOIN appointments a ON p.appointment_id = a.id
    JOIN patients pt ON a.patient_id = pt.id
    JOIN doctors d ON a.doctor_id = d.id
    WHERE p.id = ?
");
$stmt->bind_param("i", $payment_id);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();

if (!$payment) {
    header("Location: payments.php");
    exit();
}

$stmt->close();

// Set header untuk PDF
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="Invoice_' . $payment['id'] . '.pdf"');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?= $payment['id'] ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .invoice-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .clinic-info {
            width: 60%;
        }
        .invoice-info {
            width: 35%;
            text-align: right;
        }
        .patient-info, .doctor-info {
            width: 48%;
        }
        .details {
            margin: 30px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .total {
            font-weight: bold;
            font-size: 1.1em;
        }
        .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            text-align: center;
            font-size: 0.9em;
            color: #777;
        }
        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 4px;
            font-weight: bold;
        }
        .status.paid {
            background-color: #d4edda;
            color: #155724;
        }
        .status.pending {
            background-color: #fff3cd;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="invoice-container">
        <div class="header">
            <div class="clinic-info">
                <h1>Klinik Sehat Bahagia</h1>
                <p>Jl. Kesehatan No. 123, Jakarta Selatan</p>
                <p>Telp: (021) 12345678 | Email: info@kliniksehatbahagia.com</p>
            </div>
            <div class="invoice-info">
                <h2>INVOICE</h2>
                <p><strong>No:</strong> INV-<?= str_pad($payment['id'], 5, '0', STR_PAD_LEFT) ?></p>
                <p><strong>Tanggal:</strong> <?= date('d/m/Y', strtotime($payment['created_at'])) ?></p>
                <p>
                    <strong>Status:</strong> 
                    <span class="status <?= $payment['status'] ?>"><?= ucfirst($payment['status']) ?></span>
                </p>
            </div>
        </div>

        <div style="display: flex; justify-content: space-between; margin-bottom: 30px;">
            <div class="patient-info">
                <h3>Informasi Pasien</h3>
                <p><strong>Nama:</strong> <?= htmlspecialchars($payment['patient_name']) ?></p>
                <p><strong>Alamat:</strong> <?= htmlspecialchars($payment['patient_address']) ?></p>
                <p><strong>Telepon:</strong> <?= htmlspecialchars($payment['patient_phone']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($payment['patient_email']) ?></p>
            </div>
            <div class="doctor-info">
                <h3>Informasi Dokter</h3>
                <p><strong>Nama:</strong> Dr. <?= htmlspecialchars($payment['doctor_name']) ?></p>
                <p><strong>Spesialisasi:</strong> <?= htmlspecialchars($payment['specialization']) ?></p>
            </div>
        </div>

        <div class="details">
            <h3>Detail Pembayaran</h3>
            <table>
                <thead>
                    <tr>
                        <th>Deskripsi</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <strong>Konsultasi dengan Dr. <?= htmlspecialchars($payment['doctor_name']) ?></strong><br>
                            <small>Tanggal: <?= date('d F Y', strtotime($payment['appointment_date'])) ?></small><br>
                            <?php if (!empty($payment['complaint'])): ?>
                            <small>Keluhan: <?= htmlspecialchars($payment['complaint']) ?></small>
                            <?php endif; ?>
                        </td>
                        <td>Rp <?= number_format($payment['amount'], 0, ',', '.') ?></td>
                    </tr>
                    <tr class="total">
                        <td>Total</td>
                        <td>Rp <?= number_format($payment['amount'], 0, ',', '.') ?></td>
                    </tr>
                </tbody>
            </table>

            <?php if ($payment['status'] == 'paid'): ?>
            <p><strong>Tanggal Pembayaran:</strong> <?= date('d F Y H:i', strtotime($payment['payment_date'])) ?></p>
            <?php else: ?>
            <p><strong>Harap melakukan pembayaran sebelum:</strong> <?= date('d F Y', strtotime('+7 days')) ?></p>
            <?php endif; ?>
        </div>

        <div class="footer">
            <p>Terima kasih telah menggunakan layanan Klinik Sehat Bahagia</p>
            <p>Invoice ini sah dan diproses oleh komputer</p>
        </div>
    </div>
</body>
</html>