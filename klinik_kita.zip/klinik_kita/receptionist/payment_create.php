<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

// Logika untuk membuat pembayaran baru
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $appointment_id = $_POST['appointment_id'];
    $amount = $_POST['amount'];
    
    // Validasi data
    // ...
    
    // Insert ke database
    $stmt = $conn->prepare("INSERT INTO payments (appointment_id, patient_id, amount, status) 
                           SELECT ?, patient_id, ?, 'pending' FROM appointments WHERE id = ?");
    $stmt->bind_param("idi", $appointment_id, $amount, $appointment_id);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Pembayaran berhasil dibuat";
        header("Location: payments.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Gagal membuat pembayaran";
    }
}

// Ambil daftar appointment yang belum memiliki pembayaran
$appointments = $conn->query("
    SELECT a.id, a.appointment_date, p.name as patient_name 
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    LEFT JOIN payments pm ON pm.appointment_id = a.id
    WHERE pm.id IS NULL AND a.appointment_date <= CURDATE()
    ORDER BY a.appointment_date DESC
");

include '../includes/header.php';
?>

<!-- Form untuk membuat pembayaran baru -->
<div class="container mt-4">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4>Buat Pembayaran Baru</h4>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="appointment_id" class="form-label">Pilih Janji Temu</label>
                            <select class="form-select" id="appointment_id" name="appointment_id" required>
                                <option value="">Pilih Janji Temu...</option>
                                <?php while ($app = $appointments->fetch_assoc()): ?>
                                <option value="<?= $app['id'] ?>">
                                    <?= date('d/m/Y', strtotime($app['appointment_date'])) ?> - 
                                    <?= htmlspecialchars($app['patient_name']) ?>
                                </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="amount" class="form-label">Jumlah Pembayaran</label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" class="form-control" id="amount" name="amount" required min="10000" step="5000">
                            </div>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Simpan Pembayaran</button>
                            <a href="payments.php" class="btn btn-outline-secondary">Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>