<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: patients.php");
    exit();
}

$patient_id = intval($_GET['id']);

// Query untuk mendapatkan detail pasien
$query = "SELECT * FROM patients WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $patient_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: patients.php");
    exit();
}

$patient = $result->fetch_assoc();

// Query untuk mendapatkan riwayat janji pasien
$appointments_query = "SELECT 
                        a.id, 
                        a.appointment_date,
                        a.start_time,
                        a.end_time,
                        a.status,
                        a.complaint,
                        d.name as doctor_name,
                        d.specialization
                      FROM appointments a
                      JOIN doctors d ON a.doctor_id = d.id
                      WHERE a.patient_id = ?
                      ORDER BY a.appointment_date DESC, a.start_time DESC";
$appointments_stmt = $conn->prepare($appointments_query);
$appointments_stmt->bind_param("i", $patient_id);
$appointments_stmt->execute();
$appointments_result = $appointments_stmt->get_result();

// Fungsi helper untuk format tanggal dan waktu
function formatDate($date) {
    return $date ? date('d F Y', strtotime($date)) : '-';
}

function formatTime($time) {
    return $time ? date('H:i', strtotime($time)) : '-';
}

$title = "Detail Pasien: " . htmlspecialchars($patient['name']);
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?= $title ?></h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="patients.php" class="btn btn-sm btn-outline-secondary me-2">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                    <a href="patient_edit.php?id=<?= $patient_id ?>" class="btn btn-sm btn-warning me-2">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="patient_print.php?id=<?= $patient_id ?>" target="_blank" class="btn btn-sm btn-primary">
                        <i class="fas fa-print"></i> Cetak
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Informasi Pribadi</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Nama Lengkap</div>
                                <div class="col-md-8"><?= htmlspecialchars($patient['name']) ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Jenis Kelamin</div>
                                <div class="col-md-8">
                                    <?= $patient['gender'] == 'male' ? 'Laki-laki' : 'Perempuan' ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Tanggal Lahir</div>
                                <div class="col-md-8"><?= formatDate($patient['birth_date']) ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">No. Telepon</div>
                                <div class="col-md-8"><?= htmlspecialchars($patient['phone']) ?></div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Email</div>
                                <div class="col-md-8"><?= htmlspecialchars($patient['email']) ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 fw-bold">Alamat</div>
                                <div class="col-md-8"><?= nl2br(htmlspecialchars($patient['address'])) ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Informasi Medis</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Golongan Darah</div>
                                <div class="col-md-8">
                                    <?= $patient['blood_type'] ? htmlspecialchars($patient['blood_type']) : '-' ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Alergi</div>
                                <div class="col-md-8">
                                    <?= $patient['allergies'] ? nl2br(htmlspecialchars($patient['allergies'])) : '-' ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 fw-bold">Catatan Medis</div>
                                <div class="col-md-8">
                                    <?= $patient['medical_notes'] ? nl2br(htmlspecialchars($patient['medical_notes'])) : '-' ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Informasi Akun</h5>
                        </div>
                        <div class="card-body">
                            <div class="row mb-3">
                                <div class="col-md-4 fw-bold">Terdaftar Sejak</div>
                                <div class="col-md-8"><?= formatDate($patient['created_at']) ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 fw-bold">Terakhir Diupdate</div>
                                <div class="col-md-8"><?= formatDate($patient['updated_at']) ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Riwayat Janji Temu -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">Riwayat Janji Temu</h5>
                </div>
                <div class="card-body">
                    <?php if ($appointments_result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                        <th>Dokter</th>
                                        <th>Spesialisasi</th>
                                        <th>Keluhan</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($appointment = $appointments_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= formatDate($appointment['appointment_date']) ?></td>
                                            <td><?= formatTime($appointment['start_time']) ?> - <?= formatTime($appointment['end_time']) ?></td>
                                            <td>Dr. <?= htmlspecialchars($appointment['doctor_name']) ?></td>
                                            <td><?= htmlspecialchars($appointment['specialization']) ?></td>
                                            <td><?= $appointment['complaint'] ? substr(htmlspecialchars($appointment['complaint']), 0, 30) . '...' : '-' ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $appointment['status'] == 'confirmed' ? 'primary' : 
                                                    ($appointment['status'] == 'pending' ? 'warning' : 
                                                    ($appointment['status'] == 'completed' ? 'success' : 'danger')) 
                                                ?>">
                                                    <?= ucfirst($appointment['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="appointment_detail.php?id=<?= $appointment['id'] ?>" class="btn btn-sm btn-primary" title="Detail">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Pasien ini belum memiliki riwayat janji temu</div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
    .card {
        margin-bottom: 20px;
        border: none;
        border-radius: 10px;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
    }
    
    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid rgba(0, 0, 0, 0.125);
        font-weight: 600;
    }
    
    .badge {
        font-size: 0.85em;
        font-weight: 500;
        padding: 0.35em 0.65em;
    }
</style>

<?php include '../includes/footer.php'; ?>