<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

// Filter pembayaran
$filter_status = $_GET['status'] ?? 'all';
$filter_date = $_GET['date'] ?? '';

// Query pembayaran - disesuaikan dengan struktur tabel Anda
$query = "SELECT p.id, p.amount, p.status, p.payment_date, p.created_at, 
                 a.appointment_date, pt.name as patient_name, d.name as doctor_name 
          FROM payments p
          JOIN appointments a ON p.appointment_id = a.id
          JOIN patients pt ON a.patient_id = pt.id
          JOIN doctors d ON a.doctor_id = d.id";

$conditions = [];
$params = [];
$types = '';

if ($filter_status != 'all') {
    $conditions[] = "p.status = ?";
    $params[] = $filter_status;
    $types .= 's';
}

if ($filter_date) {
    $conditions[] = "DATE(a.appointment_date) = ?";
    $params[] = $filter_date;
    $types .= 's';
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$query .= " ORDER BY p.payment_date DESC, p.created_at DESC";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manajemen Pembayaran</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="payment_create.php" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-plus me-1"></i> Buat Pembayaran Baru
                    </a>
                </div>
            </div>

            <!-- Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="all" <?= $filter_status == 'all' ? 'selected' : '' ?>>Semua Status</option>
                                <option value="pending" <?= $filter_status == 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="paid" <?= $filter_status == 'paid' ? 'selected' : '' ?>>Lunas</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Tanggal Konsultasi</label>
                            <input type="date" name="date" class="form-control" value="<?= htmlspecialchars($filter_date) ?>">
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-filter"></i> Filter
                            </button>
                            <a href="payments.php" class="btn btn-outline-secondary">
                                <i class="fas fa-sync-alt"></i> Reset
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabel Pembayaran -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Daftar Pembayaran</h5>
                    <small class="text-muted">Total: <?= $result->num_rows ?> pembayaran</small>
                </div>
                <div class="card-body">
                    <?php if ($result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover" id="paymentsTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>ID Pembayaran</th>
                                        <th>Pasien</th>
                                        <th>Dokter</th>
                                        <th>Tanggal Konsultasi</th>
                                        <th>Jumlah</th>
                                        <th>Status</th>
                                        <th>Tanggal Bayar</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $counter = 1;
                                    while ($row = $result->fetch_assoc()):
                                        $appointment_date = date('d/m/Y', strtotime($row['appointment_date']));
                                        $amount = 'Rp ' . number_format($row['amount'], 0, ',', '.');
                                        $payment_date = $row['payment_date'] ? date('d/m/Y H:i', strtotime($row['payment_date'])) : '-';
                                    ?>
                                    <tr>
                                        <td><?= $counter++ ?></td>
                                        <td>PM-<?= str_pad($row['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                        <td><?= htmlspecialchars($row['patient_name']) ?></td>
                                        <td>Dr. <?= htmlspecialchars($row['doctor_name']) ?></td>
                                        <td><?= $appointment_date ?></td>
                                        <td><?= $amount ?></td>
                                        <td>
                                            <span class="badge bg-<?= getPaymentStatusColor($row['status']) ?>">
                                                <?= ucfirst($row['status']) ?>
                                            </span>
                                        </td>
                                        <td><?= $payment_date ?></td>
                                        <td>
                                            <div class="btn-group btn-group-sm" role="group">
                                                <a href="payments_detail.php?id=<?= $row['id'] ?>" class="btn btn-primary" title="Detail" data-bs-toggle="tooltip">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if ($row['status'] == 'pending'): ?>
                                                <a href="payments_process.php?id=<?= $row['id'] ?>" class="btn btn-success" title="Proses Pembayaran" data-bs-toggle="tooltip">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                                <?php endif; ?>
                                                <a href="payments_print.php?id=<?= $row['id'] ?>" class="btn btn-secondary" title="Cetak" data-bs-toggle="tooltip" target="_blank">
                                                    <i class="fas fa-print"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info mb-0">Tidak ada data pembayaran yang ditemukan.</div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</div>

<?php 
function getPaymentStatusColor($status) {
    switch ($status) {
        case 'paid': return 'success';
        case 'pending': return 'warning';
        case 'cancelled': return 'danger';
        default: return 'secondary';
    }
}

include '../includes/footer.php'; 
?>

<!-- JavaScript Tambahan -->
<script>
// Aktifkan tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Inisialisasi DataTable jika diperlukan
    if (document.getElementById('paymentsTable')) {
        $('#paymentsTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.25/i18n/Indonesian.json'
            },
            columnDefs: [
                { orderable: false, targets: [8] } // Kolom aksi tidak bisa diurutkan
            ]
        });
    }
});
</script>