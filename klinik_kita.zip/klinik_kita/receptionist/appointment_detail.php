<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: appointments.php");
    exit();
}

$appointment_id = intval($_GET['id']);

// Query untuk mendapatkan detail janji temu
$query = "SELECT 
            a.*,
            p.name as patient_name, 
            p.phone as patient_phone,
            p.email as patient_email,
            p.address as patient_address,
            p.birth_date as patient_birth_date,
            p.gender as patient_gender,
            d.name as doctor_name,
            d.specialization as doctor_specialization,
            d.room_number as doctor_room,
            s.date as schedule_date,
            s.start_time as schedule_start,
            s.end_time as schedule_end
          FROM appointments a
          JOIN patients p ON a.patient_id = p.id
          JOIN doctors d ON a.doctor_id = d.id
          LEFT JOIN schedules s ON a.schedule_id = s.id
          WHERE a.id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: appointments.php");
    exit();
}

$appointment = $result->fetch_assoc();

// Fungsi helper untuk format tanggal dan waktu
function formatDate($date) {
    return $date ? date('d F Y', strtotime($date)) : '-';
}

function formatTime($time) {
    return $time ? date('H:i', strtotime($time)) : '-';
}

$title = "Detail Janji Temu #" . $appointment['id'];
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?= $title ?></h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="appointments.php" class="btn btn-sm btn-outline-secondary me-2">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                    <a href="edit_appointment.php?id=<?= $appointment_id ?>" class="btn btn-sm btn-warning me-2">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="print_appointment.php?id=<?= $appointment_id ?>" target="_blank" class="btn btn-sm btn-primary">
                        <i class="fas fa-print"></i> Cetak
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Informasi Pasien</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <th width="30%">Nama Pasien</th>
                                    <td><?= htmlspecialchars($appointment['patient_name']) ?></td>
                                </tr>
                                <tr>
                                    <th>No. Telepon</th>
                                    <td><?= htmlspecialchars($appointment['patient_phone']) ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?= htmlspecialchars($appointment['patient_email']) ?></td>
                                </tr>
                                <tr>
                                    <th>Alamat</th>
                                    <td><?= htmlspecialchars($appointment['patient_address']) ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal Lahir</th>
                                    <td><?= formatDate($appointment['patient_birth_date']) ?></td>
                                </tr>
                                <tr>
                                    <th>Jenis Kelamin</th>
                                    <td><?= $appointment['patient_gender'] == 'male' ? 'Laki-laki' : 'Perempuan' ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Detail Janji Temu</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <th width="30%">Dokter</th>
                                    <td>Dr. <?= htmlspecialchars($appointment['doctor_name']) ?></td>
                                </tr>
                                <tr>
                                    <th>Spesialisasi</th>
                                    <td><?= htmlspecialchars($appointment['doctor_specialization']) ?></td>
                                </tr>
                                <tr>
                                    <th>Ruangan</th>
                                    <td><?= htmlspecialchars($appointment['doctor_room']) ?></td>
                                </tr>
                                <tr>
                                    <th>Tanggal Janji</th>
                                    <td><?= formatDate($appointment['appointment_date']) ?></td>
                                </tr>
                                <tr>
                                    <th>Waktu Selesai</th>
                                    <td><?= formatTime($appointment['end_time']) ?></td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <span class="badge bg-<?= 
                                            $appointment['status'] == 'confirmed' ? 'primary' : 
                                            ($appointment['status'] == 'pending' ? 'warning' : 
                                            ($appointment['status'] == 'completed' ? 'success' : 'danger')) 
                                        ?>">
                                            <?= ucfirst($appointment['status']) ?>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Pembayaran</th>
                                    <td>
                                        <?= $appointment['is_paid'] ? 
                                            '<span class="badge bg-success">Lunas</span>' : 
                                            '<span class="badge bg-danger">Belum Dibayar</span>' ?>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Keluhan Pasien</h5>
                </div>
                <div class="card-body">
                    <div class="p-3 bg-light rounded">
                        <?= nl2br(htmlspecialchars($appointment['complaint'])) ?>
                    </div>
                </div>
            </div>
            
            <!-- Riwayat Status -->
            <div class="card mt-4">
                <div class="card-header">
                    <h5 class="mb-0">Riwayat Status</h5>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <?php
                        $historyQuery = "SELECT * FROM appointment_history 
                                       WHERE appointment_id = ? 
                                       ORDER BY created_at DESC";
                        $historyStmt = $conn->prepare($historyQuery);
                        $historyStmt->bind_param("i", $appointment_id);
                        $historyStmt->execute();
                        $historyResult = $historyStmt->get_result();
                        
                        if ($historyResult->num_rows > 0) {
                            while ($history = $historyResult->fetch_assoc()) {
                                echo '<div class="timeline-item mb-3">
                                    <div class="timeline-badge bg-' . 
                                    ($history['status'] == 'confirmed' ? 'primary' : 
                                    ($history['status'] == 'pending' ? 'warning' : 
                                    ($history['status'] == 'completed' ? 'success' : 'danger'))) . '"></div>
                                    <div class="timeline-content">
                                        <div class="d-flex justify-content-between">
                                            <span class="fw-bold">' . ucfirst($history['status']) . '</span>
                                            <small class="text-muted">' . formatDate($history['created_at']) . ' ' . formatTime($history['created_at']) . '</small>
                                        </div>
                                        <p class="mb-0">' . htmlspecialchars($history['notes'] ?? 'Status diperbarui') . '</p>
                                    </div>
                                </div>';
                            }
                        } else {
                            echo '<p class="text-muted">Tidak ada riwayat status</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<style>
    .timeline {
        position: relative;
        padding-left: 20px;
    }
    
    .timeline-item {
        position: relative;
        padding-bottom: 10px;
    }
    
    .timeline-badge {
        position: absolute;
        left: -20px;
        top: 0;
        width: 12px;
        height: 12px;
        border-radius: 50%;
    }
    
    .timeline-content {
        padding-left: 15px;
    }
    
    th {
        color: #6c757d;
    }
</style>

<?php include '../includes/footer.php'; ?>