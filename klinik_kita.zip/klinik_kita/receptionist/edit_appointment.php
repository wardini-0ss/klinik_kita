<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: appointments.php");
    exit();
}

$appointment_id = intval($_GET['id']);

// Query untuk mendapatkan data janji temu
$query = "SELECT * FROM appointments WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: appointments.php");
    exit();
}

$appointment = $result->fetch_assoc();

// Ambil data pasien dan dokter
$patients = $conn->query("SELECT id, name FROM patients ORDER BY name");
$doctors = $conn->query("SELECT id, name, specialization FROM doctors ORDER BY name");

// Proses form update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_id = intval($_POST['patient_id']);
    $doctor_id = intval($_POST['doctor_id']);
    $appointment_date = $_POST['appointment_date'];
    $end_time = $_POST['end_time'];
    $complaint = $_POST['complaint'];
    $status = $_POST['status'];
    $is_paid = isset($_POST['is_paid']) ? 1 : 0;
    $notes = $_POST['notes'];
    
    $updateQuery = "UPDATE appointments SET 
                    patient_id = ?,
                    doctor_id = ?,
                    appointment_date = ?,
                    end_time = ?,
                    complaint = ?,
                    status = ?,
                    is_paid = ?,
                    notes = ?,
                    updated_at = NOW()
                    WHERE id = ?";
    
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("iissssisi", 
        $patient_id,
        $doctor_id,
        $appointment_date,
        $end_time,
        $complaint,
        $status,
        $is_paid,
        $notes,
        $appointment_id
    );
    
    if ($stmt->execute()) {
        // Catat perubahan status jika berbeda
        if ($appointment['status'] != $status) {
            $historyQuery = "INSERT INTO appointment_history 
                           (appointment_id, status, notes, created_by)
                           VALUES (?, ?, ?, ?)";
            $historyStmt = $conn->prepare($historyQuery);
            $historyStmt->bind_param("issi", 
                $appointment_id,
                $status,
                $notes,
                $_SESSION['user_id']
            );
            $historyStmt->execute();
        }
        
        $_SESSION['success'] = "Janji temu berhasil diperbarui";
        header("Location: appointment_detail.php?id=" . $appointment_id);
        exit();
    } else {
        $error = "Gagal memperbarui janji temu: " . $conn->error;
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Edit Janji Temu #<?= $appointment_id ?></h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="appointment_detail.php?id=<?= $appointment_id ?>" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Pasien</label>
                                    <select name="patient_id" class="form-select" required>
                                        <option value="">Pilih Pasien</option>
                                        <?php while ($patient = $patients->fetch_assoc()): ?>
                                            <option value="<?= $patient['id'] ?>" <?= $patient['id'] == $appointment['patient_id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($patient['name']) ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Dokter</label>
                                    <select name="doctor_id" class="form-select" required>
                                        <option value="">Pilih Dokter</option>
                                        <?php while ($doctor = $doctors->fetch_assoc()): ?>
                                            <option value="<?= $doctor['id'] ?>" <?= $doctor['id'] == $appointment['doctor_id'] ? 'selected' : '' ?>>
                                                Dr. <?= htmlspecialchars($doctor['name']) ?> (<?= htmlspecialchars($doctor['specialization']) ?>)
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tanggal Janji</label>
                                    <input type="date" name="appointment_date" class="form-control" 
                                           value="<?= htmlspecialchars($appointment['appointment_date']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Waktu Selesai</label>
                                    <input type="time" name="end_time" class="form-control" 
                                           value="<?= htmlspecialchars(substr($appointment['end_time'], 0, 5)) ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select" required>
                                        <option value="pending" <?= $appointment['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="confirmed" <?= $appointment['status'] == 'confirmed' ? 'selected' : '' ?>>Dikonfirmasi</option>
                                        <option value="completed" <?= $appointment['status'] == 'completed' ? 'selected' : '' ?>>Selesai</option>
                                        <option value="cancelled" <?= $appointment['status'] == 'cancelled' ? 'selected' : '' ?>>Dibatalkan</option>
                                    </select>
                                </div>
                                <div class="mb-3 form-check">
                                    <input type="checkbox" name="is_paid" class="form-check-input" id="is_paid" 
                                           <?= $appointment['is_paid'] ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="is_paid">Pembayaran Lunas</label>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Catatan</label>
                                    <textarea name="notes" class="form-control" rows="3"><?= htmlspecialchars($appointment['notes'] ?? '') ?></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Keluhan Utama</label>
                            <textarea name="complaint" class="form-control" rows="5" required><?= htmlspecialchars($appointment['complaint']) ?></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>