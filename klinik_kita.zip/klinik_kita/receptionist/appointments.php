<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

// Filter janji temu
$filter_date = $_GET['date'] ?? date('Y-m-d');
$filter_status = $_GET['status'] ?? 'all';
$filter_doctor = $_GET['doctor'] ?? 'all';

// Query janji temu
$query = "SELECT a.*, p.name as patient_name, d.name as doctor_name 
          FROM appointments a
          JOIN patients p ON a.patient_id = p.id
          JOIN doctors d ON a.doctor_id = d.id";

$conditions = [];
$params = [];
$types = '';

if ($filter_date) {
    $conditions[] = "a.appointment_date = ?";
    $params[] = $filter_date;
    $types .= 's';
}

if ($filter_status != 'all') {
    $conditions[] = "a.status = ?";
    $params[] = $filter_status;
    $types .= 's';
}

if ($filter_doctor != 'all') {
    $conditions[] = "a.doctor_id = ?";
    $params[] = $filter_doctor;
    $types .= 'i';
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$query .= " ORDER BY a.appointment_date, a.start_time";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Ambil daftar dokter untuk filter
$doctors = $conn->query("SELECT id, name FROM doctors ORDER BY name");
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Manajemen Janji Temu</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="appointments_create.php" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus"></i> Janji Baru
                    </a>
                    <a href="quick_registration.php" class="btn btn-sm btn-success ms-2">
                        <i class="fas fa-user-plus"></i> Pendaftaran Cepat
                    </a>
                </div>
            </div>

            <!-- Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Tanggal</label>
                            <input type="date" name="date" class="form-control" value="<?= $filter_date ?>">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="all" <?= $filter_status == 'all' ? 'selected' : '' ?>>Semua Status</option>
                                <option value="pending" <?= $filter_status == 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="confirmed" <?= $filter_status == 'confirmed' ? 'selected' : '' ?>>Dikonfirmasi</option>
                                <option value="checked_in" <?= $filter_status == 'checked_in' ? 'selected' : '' ?>>Checked In</option>
                                <option value="completed" <?= $filter_status == 'completed' ? 'selected' : '' ?>>Selesai</option>
                                <option value="cancelled" <?= $filter_status == 'cancelled' ? 'selected' : '' ?>>Dibatalkan</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Dokter</label>
                            <select name="doctor" class="form-select">
                                <option value="all" <?= $filter_doctor == 'all' ? 'selected' : '' ?>>Semua Dokter</option>
                                <?php while ($doctor = $doctors->fetch_assoc()): ?>
                                    <option value="<?= $doctor['id'] ?>" <?= $filter_doctor == $doctor['id'] ? 'selected' : '' ?>>
                                        Dr. <?= htmlspecialchars($doctor['name']) ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary me-2">
                                <i class="fas fa-filter"></i> Filter
                            </button>
                            <a href="appointments.php" class="btn btn-outline-secondary">
                                Reset
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabel Janji Temu -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="appointmentsTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Pasien</th>
                                    <th>Dokter</th>
                                    <th>Tanggal</th>
                                    <th>Waktu</th>
                                    <th>Keluhan</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 1;
                                while ($row = $result->fetch_assoc()):
                                    $appointment_date = date('d/m/Y', strtotime($row['appointment_date']));
                                    $time_range = date('H:i', strtotime($row['start_time'])) . ' - ' . date('H:i', strtotime($row['end_time']));
                                ?>
                                <tr>
                                    <td><?= $counter++ ?></td>
                                    <td><?= htmlspecialchars($row['patient_name']) ?></td>
                                    <td>Dr. <?= htmlspecialchars($row['doctor_name']) ?></td>
                                    <td><?= $appointment_date ?></td>
                                    <td><?= $time_range ?></td>
                                    <td><?= htmlspecialchars(substr($row['complaint'], 0, 30)) . (strlen($row['complaint']) > 30 ? '...' : '') ?></td>
                                    <td>
                                        <span class="badge bg-<?= getStatusColor($row['status']) ?>">
                                            <?= ucfirst($row['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="appointments_detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="appointments_edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php if ($row['status'] == 'pending' || $row['status'] == 'confirmed'): ?>
                                        <a href="appointments_cancel.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" title="Batalkan" onclick="return confirm('Yakin ingin membatalkan janji ini?')">
                                            <i class="fas fa-times"></i>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php if ($result->num_rows == 0): ?>
                                <tr>
                                    <td colspan="8" class="text-center">Tidak ada data janji temu</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php 
function getStatusColor($status) {
    switch ($status) {
        case 'completed': return 'success';
        case 'confirmed': return 'primary';
        case 'checked_in': return 'info';
        case 'pending': return 'warning';
        case 'cancelled': return 'danger';
        default: return 'secondary';
    }
}

include '../includes/footer.php'; 
?>