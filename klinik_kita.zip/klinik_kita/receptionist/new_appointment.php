<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Proses form submission
    $patient_id = intval($_POST['patient_id']);
    $doctor_id = intval($_POST['doctor_id']);
    $appointment_date = $_POST['appointment_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $complaint = $_POST['complaint'];
    
    $query = "INSERT INTO appointments 
              (patient_id, doctor_id, appointment_date, start_time, end_time, complaint, status, created_at)
              VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iissss", $patient_id, $doctor_id, $appointment_date, $start_time, $end_time, $complaint);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Janji baru berhasil dibuat";
        header("Location: appointments.php");
        exit();
    } else {
        $error = "Gagal membuat janji baru: " . $conn->error;
    }
}

// Ambil data pasien dan dokter
$patients = $conn->query("SELECT id, name FROM patients ORDER BY name");
$doctors = $conn->query("SELECT id, name, specialization FROM doctors ORDER BY name");
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Buat Janji Baru</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="appointments.php" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Pasien</label>
                                    <select name="patient_id" class="form-select" required>
                                        <option value="">Pilih Pasien</option>
                                        <?php while ($patient = $patients->fetch_assoc()): ?>
                                            <option value="<?= $patient['id'] ?>"><?= htmlspecialchars($patient['name']) ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Dokter</label>
                                    <select name="doctor_id" class="form-select" required>
                                        <option value="">Pilih Dokter</option>
                                        <?php while ($doctor = $doctors->fetch_assoc()): ?>
                                            <option value="<?= $doctor['id'] ?>">
                                                Dr. <?= htmlspecialchars($doctor['name']) ?> (<?= htmlspecialchars($doctor['specialization']) ?>)
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Tanggal Janji</label>
                                    <input type="date" name="appointment_date" class="form-control" required 
                                           min="<?= date('Y-m-d') ?>">
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Waktu Mulai</label>
                                            <input type="time" name="start_time" class="form-control" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Waktu Selesai</label>
                                            <input type="time" name="end_time" class="form-control" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Keluhan Utama</label>
                            <textarea name="complaint" class="form-control" rows="3" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Simpan Janji
                        </button>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>