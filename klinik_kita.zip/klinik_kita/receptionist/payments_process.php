<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: payments.php");
    exit();
}

$payment_id = $_GET['id'];

// Verifikasi pembayaran
$check = $conn->prepare("SELECT id FROM payments WHERE id = ? AND status = 'pending'");
$check->bind_param("i", $payment_id);
$check->execute();
$check->store_result();

if ($check->num_rows === 0) {
    $_SESSION['error_message'] = "Pembayaran tidak ditemukan atau sudah diproses";
    header("Location: payments.php");
    exit();
}

// Proses pembayaran
$update = $conn->prepare("UPDATE payments SET status = 'paid', payment_date = NOW() WHERE id = ?");
$update->bind_param("i", $payment_id);

if ($update->execute()) {
    $_SESSION['success_message'] = "Pembayaran berhasil diproses";
} else {
    $_SESSION['error_message'] = "Gagal memproses pembayaran";
}

header("Location: payments.php");
exit();
?>