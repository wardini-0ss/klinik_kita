<?php
include '../config/database.php';
include '../includes/auth.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "ID pasien tidak valid.";
    header("Location: patients.php");
    exit();
}

$id = $_GET['id'];

// Hapus pasien
$stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $_SESSION['success'] = "Pasien berhasil dihapus.";
} else {
    $_SESSION['error'] = "Gagal menghapus pasien.";
}

header("Location: patients.php");
exit();
?>