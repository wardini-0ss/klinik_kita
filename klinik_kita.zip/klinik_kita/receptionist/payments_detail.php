<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis/admin yang bisa akses
if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: payments.php");
    exit();
}

$payment_id = $_GET['id'];

// Query untuk mendapatkan detail pembayaran
$stmt = $conn->prepare("
    SELECT p.*, 
           a.appointment_date, a.complaint,
           pt.name as patient_name, pt.phone as patient_phone, pt.email as patient_email,
           d.name as doctor_name, d.specialization, d.phone as doctor_phone
    FROM payments p
    JOIN appointments a ON p.appointment_id = a.id
    JOIN patients pt ON a.patient_id = pt.id
    JOIN doctors d ON a.doctor_id = d.id
    WHERE p.id = ?
");
$stmt->bind_param("i", $payment_id);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();

if (!$payment) {
    $_SESSION['error_message'] = "Data pembayaran tidak ditemukan";
    header("Location: payments.php");
    exit();
}

$stmt->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Detail Pembayaran</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="payments_print.php?id=<?= $payment['id'] ?>" class="btn btn-sm btn-outline-secondary me-2" target="_blank">
                        <i class="fas fa-print"></i> Cetak
                    </a>
                    <a href="payments.php" class="btn btn-sm btn-outline-primary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Informasi Pembayaran</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">
                                            <strong>ID Pembayaran:</strong> PM-<?= str_pad($payment['id'], 5, '0', STR_PAD_LEFT) ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Tanggal Dibuat:</strong> <?= date('d/m/Y H:i', strtotime($payment['created_at'])) ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Status:</strong> 
                                            <span class="badge bg-<?= $payment['status'] == 'paid' ? 'success' : 'warning' ?>">
                                                <?= ucfirst($payment['status']) ?>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">
                                            <strong>Tanggal Konsultasi:</strong> <?= date('d/m/Y', strtotime($payment['appointment_date'])) ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Jumlah:</strong> Rp <?= number_format($payment['amount'], 0, ',', '.') ?>
                                        </li>
                                        <?php if ($payment['status'] == 'paid'): ?>
                                        <li class="list-group-item">
                                            <strong>Tanggal Bayar:</strong> <?= date('d/m/Y H:i', strtotime($payment['payment_date'])) ?>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">Detail Konsultasi</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>Informasi Pasien</h6>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">
                                            <strong>Nama:</strong> <?= htmlspecialchars($payment['patient_name']) ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Telepon:</strong> <?= htmlspecialchars($payment['patient_phone']) ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Email:</strong> <?= htmlspecialchars($payment['patient_email']) ?>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h6>Informasi Dokter</h6>
                                    <ul class="list-group list-group-flush">
                                        <li class="list-group-item">
                                            <strong>Nama:</strong> Dr. <?= htmlspecialchars($payment['doctor_name']) ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Spesialisasi:</strong> <?= htmlspecialchars($payment['specialization']) ?>
                                        </li>
                                        <li class="list-group-item">
                                            <strong>Telepon:</strong> <?= htmlspecialchars($payment['doctor_phone']) ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <h6>Keluhan Pasien</h6>
                                <div class="border p-3 rounded bg-light">
                                    <?= !empty($payment['complaint']) ? nl2br(htmlspecialchars($payment['complaint'])) : 'Tidak ada keluhan dicatat' ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Aksi</h5>
                        </div>
                        <div class="card-body">
                            <?php if ($payment['status'] == 'pending'): ?>
                                <a href="payments_process.php?id=<?= $payment['id'] ?>" class="btn btn-success w-100 mb-2">
                                    <i class="fas fa-check-circle"></i> Konfirmasi Pembayaran
                                </a>
                            <?php endif; ?>
                            
                            <a href="payments_print.php?id=<?= $payment['id'] ?>" class="btn btn-outline-primary w-100 mb-2" target="_blank">
                                <i class="fas fa-print"></i> Cetak Invoice
                            </a>
                            
                            <button type="button" class="btn btn-outline-secondary w-100 mb-2" data-bs-toggle="modal" data-bs-target="#editPaymentModal">
                                <i class="fas fa-edit"></i> Edit Pembayaran
                            </button>
                            
                            <button type="button" class="btn btn-outline-danger w-100" data-bs-toggle="modal" data-bs-target="#cancelPaymentModal">
                                <i class="fas fa-times-circle"></i> Batalkan Pembayaran
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Modal Edit Pembayaran -->
<div class="modal fade" id="editPaymentModal" tabindex="-1" aria-labelledby="editPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editPaymentModalLabel">Edit Pembayaran</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="payments_update.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $payment['id'] ?>">
                    <div class="mb-3">
                        <label for="amount" class="form-label">Jumlah Pembayaran</label>
                        <div class="input-group">
                            <span class="input-group-text">Rp</span>
                            <input type="number" class="form-control" id="amount" name="amount" 
                                   value="<?= $payment['amount'] ?>" required min="10000" step="5000">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Batalkan Pembayaran -->
<div class="modal fade" id="cancelPaymentModal" tabindex="-1" aria-labelledby="cancelPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="cancelPaymentModalLabel">Batalkan Pembayaran</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="payments_cancel.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $payment['id'] ?>">
                    <p>Anda yakin ingin membatalkan pembayaran ini?</p>
                    <div class="mb-3">
                        <label for="cancel_reason" class="form-label">Alasan Pembatalan</label>
                        <textarea class="form-control" id="cancel_reason" name="cancel_reason" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger">Ya, Batalkan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>