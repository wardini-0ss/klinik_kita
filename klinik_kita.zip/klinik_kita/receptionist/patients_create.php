<?php
include '../config/database.php';
include '../includes/auth.php';

// Verify receptionist role
if ($_SESSION['role'] != 'receptionist') {
    header("Location: ../login.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $blood_type = $_POST['blood_type'] ?? 'unknown';
    $allergies = $_POST['allergies'] ?? null;
    $medical_notes = $_POST['medical_notes'] ?? null;
    
    try {
        $stmt = $conn->prepare("INSERT INTO patients (name, email, password, phone, address, birth_date, gender, blood_type, allergies, medical_notes) VALUES (?, '', '', ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $name, $phone, $address, $birthdate, $gender, $blood_type, $allergies, $medical_notes);
        
        if ($stmt->execute()) {
            $patient_id = $conn->insert_id;
            $success = "Pasien berhasil didaftarkan! ID Pasien: <strong>$patient_id</strong>";
        } else {
            $error = "Gagal mendaftarkan pasien: " . $conn->error;
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Pendaftaran Pasien Baru</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="patients.php" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali ke Daftar Pasien
                    </a>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>

            <div class="card shadow">
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Nama Lengkap*</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tanggal Lahir*</label>
                                    <input type="date" name="birthdate" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Jenis Kelamin*</label>
                                    <select name="gender" class="form-select" required>
                                        <option value="">Pilih Jenis Kelamin</option>
                                        <option value="male">Laki-laki</option>
                                        <option value="female">Perempuan</option>
                                        <option value="other">Lainnya</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Golongan Darah</label>
                                    <select name="blood_type" class="form-select">
                                        <option value="unknown">Tidak Tahu</option>
                                        <option value="A">A</option>
                                        <option value="B">B</option>
                                        <option value="AB">AB</option>
                                        <option value="O">O</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Alamat Lengkap*</label>
                                    <textarea name="address" class="form-control" rows="3" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nomor Telepon*</label>
                                    <input type="tel" name="phone" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Alergi</label>
                                    <textarea name="allergies" class="form-control" rows="2" placeholder="Daftar alergi yang diketahui"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Catatan Medis</label>
                                    <textarea name="medical_notes" class="form-control" rows="2" placeholder="Riwayat penyakit atau catatan penting lainnya"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-user-plus"></i> Daftarkan Pasien
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>