<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'receptionist') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $patient_name = $_POST['patient_name'];
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];
    
    // Validasi data
    if (empty($patient_name) || empty($doctor_id) || empty($appointment_date)) {
        $_SESSION['error'] = "Semua field harus diisi";
        header("Location: new_appointment.php");
        exit();
    }
    
    // Cek apakah dokter tersedia
    $doctor = $conn->query("SELECT id FROM doctors WHERE id = $doctor_id")->fetch_assoc();
    if (!$doctor) {
        $_SESSION['error'] = "Dokter tidak ditemukan";
        header("Location: new_appointment.php");
        exit();
    }
    
    // Buat janji
    $stmt = $conn->prepare("INSERT INTO appointments (patient_name, doctor_id, appointment_date, status) VALUES (?, ?, ?, 'pending')");
    $stmt->bind_param("sis", $patient_name, $doctor_id, $appointment_date);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Janji berhasil dibuat";
        header("Location: dashboard.php");
        exit();
    } else {
        $_SESSION['error'] = "Gagal membuat janji: " . $conn->error;
        header("Location: new_appointment.php");
        exit();
    }
}

header("Location: dashboard.php");
exit();
?>