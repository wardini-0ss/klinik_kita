<?php
include '../config/database.php';
include '../includes/auth.php';

// Pastikan hanya resepsionis yang bisa akses
if ($_SESSION['role'] != 'receptionist') {
    header("Location: ../login.php");
    exit();
}

// Proses form pendaftaran
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $birth_date = $_POST['birth_date'] ?? null;
    $gender = $_POST['gender'] ?? 'other';
    $address = $_POST['address'] ?? '';
    
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];
    $start_time = $_POST['start_time'];
    $complaint = $_POST['complaint'] ?? '';
    
    // Mulai transaksi
    $conn->begin_transaction();
    
    try {
        // 1. Buat pasien baru
        $patient_query = "INSERT INTO patients (name, email, phone, birth_date, gender, address) 
                          VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($patient_query);
        $stmt->bind_param("ssssss", $name, $email, $phone, $birth_date, $gender, $address);
        $stmt->execute();
        $patient_id = $conn->insert_id;
        
        // 2. Buat appointment
        $appointment_query = "INSERT INTO appointments 
                              (patient_id, doctor_id, appointment_date, start_time, end_time, complaint, status) 
                              VALUES (?, ?, ?, ?, DATE_ADD(?, INTERVAL 30 MINUTE), ?, 'confirmed')";
        $stmt = $conn->prepare($appointment_query);
        $stmt->bind_param("iissss", $patient_id, $doctor_id, $appointment_date, $start_time, $start_time, $complaint);
        $stmt->execute();
        $appointment_id = $conn->insert_id;
        
        // 3. Buat record pembayaran awal
        $payment_query = "INSERT INTO payments (appointment_id, amount, status) 
                          VALUES (?, 150000, 'pending')";
        $stmt = $conn->prepare($payment_query);
        $stmt->bind_param("i", $appointment_id);
        $stmt->execute();
        
        // Commit transaksi
        $conn->commit();
        
        $_SESSION['success'] = "Pendaftaran cepat berhasil! ID Pasien: $patient_id";
        header("Location: appointments_detail.php?id=$appointment_id");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = "Gagal melakukan pendaftaran: " . $e->getMessage();
    }
}

// Ambil daftar dokter
$doctors = $conn->query("SELECT id, name, specialization FROM doctors ORDER BY name");
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Pendaftaran Cepat Pasien</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="appointments.php" class="btn btn-sm btn-outline-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form method="POST">
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="mb-3">Data Pasien</h5>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nama Lengkap*</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email*</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nomor Telepon*</label>
                                <input type="text" name="phone" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal Lahir</label>
                                <input type="date" name="birth_date" class="form-control">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Jenis Kelamin</label>
                                <select name="gender" class="form-select">
                                    <option value="male">Laki-laki</option>
                                    <option value="female">Perempuan</option>
                                    <option value="other">Lainnya</option>
                                </select>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Alamat</label>
                                <textarea name="address" class="form-control" rows="2"></textarea>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h5 class="mb-3">Janji Temu</h5>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Dokter*</label>
                                <select name="doctor_id" class="form-select" required>
                                    <option value="">Pilih Dokter</option>
                                    <?php while ($doctor = $doctors->fetch_assoc()): ?>
                                        <option value="<?= $doctor['id'] ?>">
                                            Dr. <?= htmlspecialchars($doctor['name']) ?> - <?= htmlspecialchars($doctor['specialization']) ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal*</label>
                                <input type="date" name="appointment_date" class="form-control" required min="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Waktu Mulai*</label>
                                <input type="time" name="start_time" class="form-control" required min="08:00" max="16:00">
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Keluhan</label>
                                <textarea name="complaint" class="form-control" rows="3"></textarea>
                            </div>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="reset" class="btn btn-outline-secondary me-md-2">
                                <i class="fas fa-undo"></i> Reset
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Simpan Pendaftaran
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<script>
$(document).ready(function() {
    // Validasi form
    $('form').submit(function() {
        const appointmentDate = new Date($('[name="appointment_date"]').val());
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (appointmentDate < today) {
            alert('Tanggal janji tidak boleh di masa lalu');
            return false;
        }
        
        const startTime = $('[name="start_time"]').val();
        const hour = parseInt(startTime.split(':')[0]);
        
        if (hour < 8 || hour > 16) {
            alert('Waktu janji harus antara jam 08:00 - 16:00');
            return false;
        }
        
        return true;
    });
});
</script>

<?php include '../includes/footer.php'; ?>