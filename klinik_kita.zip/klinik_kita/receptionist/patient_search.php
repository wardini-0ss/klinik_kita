<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'receptionist') {
    header("Location: ../login.php");
    exit();
}

$search_term = '';
$results = [];

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
    $search_term = trim($_GET['search']);
    if (!empty($search_term)) {
        $stmt = $conn->prepare("
            SELECT p.*, COUNT(a.id) as appointment_count 
            FROM patients p
            LEFT JOIN appointments a ON p.id = a.patient_id
            WHERE p.name LIKE ? OR p.phone LIKE ? OR p.email LIKE ?
            GROUP BY p.id
        ");
        $search_param = "%$search_term%";
        $stmt->bind_param("sss", $search_param, $search_param, $search_param);
        $stmt->execute();
        $results = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Pencarian Pasien</h3>
    
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan nama, telepon, atau email..." value="<?= htmlspecialchars($search_term) ?>">
                    <button type="submit" class="btn btn-primary">Cari</button>
                </div>
            </form>
        </div>
    </div>
    
    <?php if (!empty($search_term)): ?>
        <div class="card">
            <div class="card-header">
                <h5>Hasil Pencarian</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($results)): ?>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama</th>
                                    <th>Telepon</th>
                                    <th>Email</th>
                                    <th>Total Kunjungan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($results as $patient): ?>
                                    <tr>
                                        <td><?= $patient['id'] ?></td>
                                        <td><?= htmlspecialchars($patient['name']) ?></td>
                                        <td><?= htmlspecialchars($patient['phone']) ?></td>
                                        <td><?= htmlspecialchars($patient['email']) ?></td>
                                        <td><?= $patient['appointment_count'] ?></td>
                                        <td>
                                            <a href="patient_detail.php?id=<?= $patient['id'] ?>" class="btn btn-sm btn-info">Detail</a>
                                            <a href="new_appointment.php?patient_id=<?= $patient['id'] ?>" class="btn btn-sm btn-primary">Buat Janji</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center text-muted">Tidak ditemukan pasien dengan kata kunci "<?= htmlspecialchars($search_term) ?>"</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php include '../includes/footer.php'; ?>