<?php
include '../config/database.php';
include '../includes/auth.php';
include '../includes/functions.php';

if (!in_array($_SESSION['role'], ['receptionist', 'admin'])) {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "ID pasien tidak valid.";
    header("Location: patients.php");
    exit();
}

$id = $_GET['id'];
$error = '';
$success = '';

// Ambil data pasien
$stmt = $conn->prepare("SELECT * FROM patients WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    $_SESSION['error'] = "Pasien tidak ditemukan.";
    header("Location: patients.php");
    exit();
}

$patient = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $birth_date = $_POST['birth_date'];
    $gender = $_POST['gender'];
    $blood_type = $_POST['blood_type'];
    $allergies = $_POST['allergies'];
    $medical_notes = $_POST['medical_notes'];

    if (empty($name) || empty($email)) {
        $error = "Nama dan Email wajib diisi.";
    } else {
        $stmt = $conn->prepare("
            UPDATE patients 
            SET name=?, email=?, phone=?, address=?, birth_date=?, gender=?, blood_type=?, allergies=?, medical_notes=? 
            WHERE id=?
        ");
        $stmt->bind_param(
            "ssssssssssi",
            $name, $email, $phone, $address, $birth_date, $gender, $blood_type, $allergies, $medical_notes, $id
        );
        
        if ($stmt->execute()) {
            $success = "Data pasien berhasil diperbarui!";
            header("Location: patients.php?success=1");
            exit();
        } else {
            $error = "Gagal memperbarui data pasien.";
        }
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Edit Data Pasien</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <a href="patients.php" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>

            <div class="card shadow">
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Nama Lengkap</label>
                                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($patient['name']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($patient['email']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nomor Telepon</label>
                                    <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($patient['phone']) ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Tanggal Lahir</label>
                                    <input type="date" name="birth_date" class="form-control" value="<?= $patient['birth_date'] ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Jenis Kelamin</label>
                                    <select name="gender" class="form-select" required>
                                        <?= generateGenderOptions($patient['gender']) ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Golongan Darah</label>
                                    <select name="blood_type" class="form-select" required>
                                        <?= generateBloodTypeOptions($patient['blood_type']) ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Alamat</label>
                                    <textarea name="address" class="form-control" rows="4"><?= htmlspecialchars($patient['address']) ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Allergi</label>
                                    <textarea name="allergies" class="form-control" rows="4"><?= htmlspecialchars($patient['allergies']) ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Catatan Medis</label>
                                    <textarea name="medical_notes" class="form-control" rows="4"><?= htmlspecialchars($patient['medical_notes']) ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Simpan Perubahan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<?php include '../includes/footer.php'; ?>