<?php
include '../config/database.php'; 
include '../includes/auth.php';
if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Kelola Data Dokter</h3>
    
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Daftar Dokter</h5>
            <a href="add_doctor.php" class="btn btn-primary btn-sm">+ Tambah Dokter</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Spesialisasi</th>
                            <th>Email</th>
                            <th>Telepon</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT * FROM doctors ORDER BY name");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$row['id']}</td>
                                <td>Dr. {$row['name']}</td>
                                <td>{$row['specialization']}</td>
                                <td>{$row['email']}</td>
                                <td>{$row['phone']}</td>
                                <td>
                                    <a href='edit_doctor.php?id={$row['id']}' class='btn btn-sm btn-warning'>Edit</a>
                                    <a href='delete_doctor.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin hapus data dokter ini?\")'>Hapus</a>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>