<?php
include '../config/database.php'; 
include '../includes/auth.php';
if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$type = isset($_GET['type']) ? $_GET['type'] : '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!in_array($type, ['receptionist', 'admin']) || $id <= 0) {
    header("Location: manage_staff.php");
    exit();
}

$table = $type . 's';

// Cek apakah staff ada
$staff = $conn->query("SELECT id FROM $table WHERE id = $id")->fetch_assoc();
if (!$staff) {
    header("Location: manage_staff.php");
    exit();
}

// Jangan izinkan admin menghapus dirinya sendiri
if ($type == 'admin' && $id == $_SESSION['user_id']) {
    $_SESSION['error'] = "Anda tidak dapat menghapus akun sendiri";
    header("Location: manage_staff.php");
    exit();
}

// Proses penghapusan
if ($conn->query("DELETE FROM $table WHERE id = $id")) {
    $_SESSION['success'] = "Data $type berhasil dihapus";
} else {
    $_SESSION['error'] = "Gagal menghapus data $type";
}

header("Location: manage_staff.php");
exit();
?>