<?php
include '../config/database.php'; 
include '../includes/auth.php';
// Pastikan hanya admin yang bisa akses
if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Admin Dashboard - Selamat datang, <?= htmlspecialchars($_SESSION['name']) ?></h3>
    
    <div class="row">
        <!-- Card Statistik -->
        <div class="col-md-3 mb-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Pasien</h5>
                    <p class="card-text display-6">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) FROM patients");
                        echo $result->fetch_row()[0];
                        ?>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Dokter</h5>
                    <p class="card-text display-6">
                        <?php
                        $result = $conn->query("SELECT COUNT(*) FROM doctors");
                        echo $result->fetch_row()[0];
                        ?>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Janji Hari Ini</h5>
                    <p class="card-text display-6">
                        <?php
                        $today = date('Y-m-d');
                        $result = $conn->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = '$today'");
                        echo $result->fetch_row()[0];
                        ?>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-4">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <h5 class="card-title">Pendapatan Bulan Ini</h5>
                    <p class="card-text display-6">
                        <?php
                        $month = date('Y-m');
                        $result = $conn->query("SELECT SUM(amount) FROM payments WHERE payment_date LIKE '$month%'");
                        echo 'Rp ' . number_format($result->fetch_row()[0] ?? 0, 0, ',', '.');
                        ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Manajemen Sistem</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="manage_doctors.php" class="btn btn-outline-primary">Kelola Dokter</a>
                        <a href="manage_staff.php" class="btn btn-outline-secondary">Kelola Staf</a>
                        <a href="reports.php" class="btn btn-outline-success">Laporan</a>
                        <a href="settings.php" class="btn btn-outline-danger">Pengaturan Sistem</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Janji Terbaru</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Pasien</th>
                                    <th>Dokter</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $result = $conn->query("
                                    SELECT a.appointment_date, p.name as patient_name, d.name as doctor_name, a.status 
                                    FROM appointments a
                                    JOIN patients p ON a.patient_id = p.id
                                    JOIN doctors d ON a.doctor_id = d.id
                                    ORDER BY a.appointment_date DESC LIMIT 5
                                ");
                                
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>
                                        <td>{$row['appointment_date']}</td>
                                        <td>{$row['patient_name']}</td>
                                        <td>{$row['doctor_name']}</td>
                                        <td><span class='badge bg-" . getStatusColor($row['status']) . "'>{$row['status']}</span></td>
                                    </tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
function getStatusColor($status) {
    switch ($status) {
        case 'completed': return 'success';
        case 'confirmed': return 'primary';
        case 'pending': return 'warning';
        default: return 'secondary';
    }
}
include '../includes/footer.php'; 
?>