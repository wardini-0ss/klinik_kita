<?php
include '../config/database.php'; 
include '../includes/auth.php';
if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Kelola Staff Klinik</h3>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Daftar Staff</h5>
            <div>
                <a href="add_staff.php?role=receptionist" class="btn btn-primary btn-sm">+ Resepsionis</a>
                <a href="add_staff.php?role=admin" class="btn btn-success btn-sm">+ Admin</a>
            </div>
        </div>
        <div class="card-body">
            <ul class="nav nav-tabs" id="staffTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#receptionists" type="button">Resepsionis</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#admins" type="button">Admin</button>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active" id="receptionists">
                    <table class="table table-striped mt-3">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Tanggal Dibuat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM receptionists ORDER BY name");
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['id']}</td>
                                    <td>{$row['name']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['created_at']}</td>
                                    <td>
                                        <a href='edit_staff.php?type=receptionist&id={$row['id']}' class='btn btn-sm btn-warning'>Edit</a>
                                        <a href='delete_staff.php?type=receptionist&id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin hapus data resepsionis ini?\")'>Hapus</a>
                                    </td>
                                </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="tab-pane fade" id="admins">
                    <table class="table table-striped mt-3">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Tanggal Dibuat</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM admins ORDER BY name");
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['id']}</td>
                                    <td>{$row['name']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['created_at']}</td>
                                    <td>
                                        <a href='edit_staff.php?type=admin&id={$row['id']}' class='btn btn-sm btn-warning'>Edit</a>
                                        <a href='delete_staff.php?type=admin&id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin hapus data admin ini?\")'>Hapus</a>
                                    </td>
                                </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>