<?php
include '../includes/auth.php';
if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Proses update pengaturan
    $_SESSION['success'] = "Pengaturan berhasil diperbarui";
    header("Location: settings.php");
    exit();
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Pengaturan Sistem</h3>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Klinik</label>
                    <input type="text" name="clinic_name" class="form-control" value="Klinik Sehat">
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat Klinik</label>
                    <textarea name="clinic_address" class="form-control">Jl. Kesehatan No. 123, Kota Sejahtera</textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Telepon Klinik</label>
                    <input type="text" name="clinic_phone" class="form-control" value="(021) 12345678">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email Klinik</label>
                    <input type="email" name="clinic_email" class="form-control" value="info@kliniksehat.com">
                </div>
                <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>