<?php
include '../includes/auth.php';
if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Laporan Klinik</h3>
    
    <div class="card mb-4">
        <div class="card-header">
            <h5>Filter Laporan</h5>
        </div>
        <div class="card-body">
            <form method="GET">
                <div class="row">
                    <div class="col-md-4">
                        <label>Tanggal Mulai</label>
                        <input type="date" name="start_date" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label>Tanggal Akhir</label>
                        <input type="date" name="end_date" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label>Jenis Laporan</label>
                        <select name="report_type" class="form-select">
                            <option value="appointments">Janji Konsultasi</option>
                            <option value="payments">Pembayaran</option>
                            <option value="patients">Pasien Baru</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Tampilkan</button>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5>Hasil Laporan</h5>
            <button class="btn btn-success" onclick="window.print()">Cetak Laporan</button>
        </div>
        <div class="card-body">
            <!-- Hasil laporan akan ditampilkan di sini -->
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>