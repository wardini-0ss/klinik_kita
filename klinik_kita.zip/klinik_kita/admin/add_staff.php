<?php
include '../config/database.php'; 
include '../includes/auth.php';
if ($_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit();
}

$role = isset($_GET['role']) ? $_GET['role'] : '';
if (!in_array($role, ['receptionist', 'admin'])) {
    header("Location: manage_staff.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $table = $role . 's'; // receptionists atau admins
    $stmt = $conn->prepare("INSERT INTO $table (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Data $role berhasil ditambahkan";
        header("Location: manage_staff.php");
        exit();
    } else {
        $error = "Gagal menambahkan $role: " . $conn->error;
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Tambah <?= ucfirst($role) ?> Baru</h3>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required minlength="6">
                </div>
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="manage_staff.php" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>