<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

$patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : 0;
$doctor_id = $_SESSION['user_id'];

// Validasi pasien
$patient = $conn->query("
    SELECT p.* FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    WHERE p.id = $patient_id AND a.doctor_id = $doctor_id
    LIMIT 1
")->fetch_assoc();

if (!$patient) {
    header("Location: dashboard.php");
    exit();
}

// Ambil riwayat konsultasi
$history = $conn->query("
    SELECT a.appointment_date, a.complaint, mr.diagnosis, mr.treatment, mr.prescription
    FROM appointments a
    LEFT JOIN medical_records mr ON a.id = mr.appointment_id
    WHERE a.patient_id = $patient_id AND a.doctor_id = $doctor_id
    ORDER BY a.appointment_date DESC
");
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Riwayat Pasien</h3>
    
    <div class="card mb-4">
        <div class="card-header">
            <h5>Profil Pasien</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Nama:</strong> <?= htmlspecialchars($patient['name']) ?></p>
                    <p><strong>Tanggal Lahir:</strong> <?= date('d/m/Y', strtotime($patient['birth_date'])) ?></p>
                    <p><strong>Alamat:</strong> <?= htmlspecialchars($patient['address']) ?></p>
                </div>
                <div class="col-md-6">
                    <p><strong>Jenis Kelamin:</strong> <?= $patient['gender'] == 'M' ? 'Laki-laki' : 'Perempuan' ?></p>
                    <p><strong>Golongan Darah:</strong> <?= $patient['blood_type'] ?: '-' ?></p>
                    <p><strong>Telepon:</strong> <?= htmlspecialchars($patient['phone']) ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h5>Riwayat Konsultasi</h5>
        </div>
        <div class="card-body">
            <?php if ($history->num_rows > 0): ?>
                <div class="accordion" id="historyAccordion">
                    <?php while ($row = $history->fetch_assoc()): ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $row['appointment_date'] ?>">
                                    <?= date('d/m/Y H:i', strtotime($row['appointment_date'])) ?>
                                    - <?= $row['diagnosis'] ? 'Sudah diperiksa' : 'Belum diperiksa' ?>
                                </button>
                            </h2>
                            <div id="collapse<?= $row['appointment_date'] ?>" class="accordion-collapse collapse" data-bs-parent="#historyAccordion">
                                <div class="accordion-body">
                                    <p><strong>Keluhan:</strong> <?= htmlspecialchars($row['complaint']) ?></p>
                                    <?php if ($row['diagnosis']): ?>
                                        <p><strong>Diagnosis:</strong> <?= htmlspecialchars($row['diagnosis']) ?></p>
                                        <p><strong>Tindakan:</strong> <?= htmlspecialchars($row['treatment']) ?></p>
                                        <?php if ($row['prescription']): ?>
                                            <p><strong>Resep:</strong></p>
                                            <div class="bg-light p-3 rounded">
                                                <?= nl2br(htmlspecialchars($row['prescription'])) ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <p class="text-muted">Belum ada rekam medis</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p class="text-center text-muted">Belum ada riwayat konsultasi</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>