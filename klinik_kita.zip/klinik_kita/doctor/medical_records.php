<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['appointment_id'])) {
    header("Location: appointments.php");
    exit();
}

$appointment_id = $_GET['appointment_id'];
$doctor_id = $_SESSION['user_id'];

// Get appointment details
$stmt = $conn->prepare("
    SELECT a.*, p.name as patient_name, p.gender, p.birth_date, p.blood_type, p.address, p.phone
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    WHERE a.id = ? AND a.doctor_id = ?
");
$stmt->bind_param("ii", $appointment_id, $doctor_id);
$stmt->execute();
$appointment = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$appointment) {
    header("Location: appointments.php");
    exit();
}

// Get medical history
$stmt = $conn->prepare("
    SELECT * FROM medical_records 
    WHERE appointment_id = ?
    ORDER BY created_at DESC
");
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$medical_records = $stmt->get_result();
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $notes = $_POST['notes'];
    
    $stmt = $conn->prepare("
        INSERT INTO medical_records 
        (appointment_id, diagnosis, treatment, notes, doctor_id) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("isssi", $appointment_id, $diagnosis, $treatment, $notes, $doctor_id);
    $stmt->execute();
    
    // Update appointment status
    $update_stmt = $conn->prepare("
        UPDATE appointments SET status = 'completed' WHERE id = ?
    ");
    $update_stmt->bind_param("i", $appointment_id);
    $update_stmt->execute();
    $update_stmt->close();
    
    header("Location: medical_record.php?appointment_id=$appointment_id");
    exit();
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Rekam Medis</h3>
        <a href="appointments.php" class="btn btn-outline-secondary">Kembali</a>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Informasi Pasien</h5>
                </div>
                <div class="card-body">
                    <p><strong>Nama:</strong> <?= htmlspecialchars($appointment['patient_name']) ?></p>
                    <p><strong>Jenis Kelamin:</strong> <?= $appointment['gender'] == 'L' ? 'Laki-laki' : 'Perempuan' ?></p>
                    <p><strong>Tanggal Lahir:</strong> <?= date('d/m/Y', strtotime($appointment['birth_date'])) ?></p>
                    <p><strong>Gol. Darah:</strong> <?= $appointment['blood_type'] ?: '-' ?></p>
                    <p><strong>Alamat:</strong> <?= htmlspecialchars($appointment['address']) ?></p>
                    <p><strong>Telepon:</strong> <?= htmlspecialchars($appointment['phone']) ?></p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5>Informasi Janji Temu</h5>
                </div>
                <div class="card-body">
                    <p><strong>Tanggal:</strong> <?= date('d/m/Y', strtotime($appointment['appointment_date'])) ?></p>
                    <p><strong>Keluhan:</strong> <?= htmlspecialchars($appointment['complaint']) ?></p>
                    <p><strong>Status:</strong> 
                        <span class="badge bg-<?= 
                            $appointment['status'] == 'completed' ? 'success' : 
                            ($appointment['status'] == 'confirmed' ? 'info' : 'warning')
                        ?>">
                            <?= ucfirst($appointment['status']) ?>
                        </span>
                    </p>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Tambah Rekam Medis</h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label for="diagnosis" class="form-label">Diagnosis</label>
                            <textarea class="form-control" id="diagnosis" name="diagnosis" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="treatment" class="form-label">Pengobatan</label>
                            <textarea class="form-control" id="treatment" name="treatment" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="notes" class="form-label">Catatan Tambahan</label>
                            <textarea class="form-control" id="notes" name="notes" rows="2"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Rekam Medis</button>
                    </form>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5>Riwayat Rekam Medis</h5>
                </div>
                <div class="card-body">
                    <?php if ($medical_records->num_rows > 0): ?>
                        <div class="accordion" id="medicalHistoryAccordion">
                            <?php while ($record = $medical_records->fetch_assoc()): ?>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="heading<?= $record['id'] ?>">
                                        <button class="accordion-button collapsed" type="button" 
                                                data-bs-toggle="collapse" data-bs-target="#collapse<?= $record['id'] ?>" 
                                                aria-expanded="false" aria-controls="collapse<?= $record['id'] ?>">
                                            <?= date('d/m/Y H:i', strtotime($record['created_at'])) ?>
                                        </button>
                                    </h2>
                                    <div id="collapse<?= $record['id'] ?>" class="accordion-collapse collapse" 
                                         aria-labelledby="heading<?= $record['id'] ?>" 
                                         data-bs-parent="#medicalHistoryAccordion">
                                        <div class="accordion-body">
                                            <p><strong>Diagnosis:</strong> <?= nl2br(htmlspecialchars($record['diagnosis'])) ?></p>
                                            <p><strong>Pengobatan:</strong> <?= nl2br(htmlspecialchars($record['treatment'])) ?></p>
                                            <?php if (!empty($record['notes'])): ?>
                                                <p><strong>Catatan:</strong> <?= nl2br(htmlspecialchars($record['notes'])) ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Belum ada rekam medis untuk pasien ini.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>