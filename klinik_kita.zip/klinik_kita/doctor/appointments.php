<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];
$filter_date = $_GET['date'] ?? date('Y-m-d');
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Daftar Janji Temu</h3>
        <div>
            <a href="dashboard.php" class="btn btn-outline-secondary">Kembali ke Dashboard</a>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <div class="row">
                <div class="col-md-6">
                    <h5>Filter Tanggal</h5>
                </div>
                <div class="col-md-6">
                    <form method="get" class="row g-2">
                        <div class="col-md-8">
                            <input type="date" name="date" value="<?= $filter_date ?>" class="form-control">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php
            $stmt = $conn->prepare("
                SELECT a.id, a.appointment_date, a.status, p.name as patient_name, p.phone, a.complaint
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                WHERE a.doctor_id = ? 
                AND a.appointment_date = ?
                ORDER BY a.appointment_date
            ");
            $stmt->bind_param("is", $doctor_id, $filter_date);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Pasien</th>
                                <th>Telepon</th>
                                <th>Keluhan</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['patient_name']) ?></td>
                                    <td><?= htmlspecialchars($row['phone']) ?></td>
                                    <td><?= htmlspecialchars($row['complaint']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= 
                                            $row['status'] == 'completed' ? 'success' : 
                                            ($row['status'] == 'confirmed' ? 'info' : 'warning')
                                        ?>">
                                            <?= ucfirst($row['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="medical_record.php?appointment_id=<?= $row['id'] ?>" 
                                           class="btn btn-sm btn-primary">
                                            Rekam Medis
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Tidak ada janji temu pada tanggal ini.</div>
            <?php endif; 
            $stmt->close();
            ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>