<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Hapus jadwal lama
    $conn->query("DELETE FROM schedules WHERE doctor_id = $doctor_id");
    
    // Simpan jadwal baru
    $days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $stmt = $conn->prepare("INSERT INTO schedules (doctor_id, day, start_time, end_time) VALUES (?, ?, ?, ?)");
    
    foreach ($days as $day) {
        if (!empty($_POST[$day.'_start'])) {
            $start_time = $_POST[$day.'_start'];
            $end_time = $_POST[$day.'_end'];
            $stmt->bind_param("isss", $doctor_id, $day, $start_time, $end_time);
            $stmt->execute();
        }
    }
    
    $_SESSION['success'] = "Jadwal praktek berhasil diperbarui";
    header("Location: schedule.php");
    exit();
}

// Ambil jadwal saat ini
$schedules = $conn->query("
    SELECT day, start_time, end_time 
    FROM schedules 
    WHERE doctor_id = $doctor_id
")->fetch_all(MYSQLI_ASSOC);

// Konversi ke format yang mudah diakses
$current_schedule = [];
foreach ($schedules as $s) {
    $current_schedule[$s['day']] = [
        'start' => $s['start_time'],
        'end' => $s['end_time']
    ];
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <h3 class="mb-4">Kelola Jadwal Praktek</h3>
    
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Hari</th>
                                <th>Jam Mulai</th>
                                <th>Jam Selesai</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                            foreach ($days as $day) {
                                $start = $current_schedule[$day]['start'] ?? '';
                                $end = $current_schedule[$day]['end'] ?? '';
                                
                                echo "<tr>
                                    <td>$day</td>
                                    <td>
                                        <input type='time' name='{$day}_start' class='form-control' value='$start'>
                                    </td>
                                    <td>
                                        <input type='time' name='{$day}_end' class='form-control' value='$end'>
                                    </td>
                                    <td>
                                        <button type='button' class='btn btn-sm btn-outline-danger btn-clear' data-day='$day'>
                                            <i class='fas fa-times'></i>
                                        </button>
                                    </td>
                                </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Simpan Jadwal</button>
            </form>
        </div>
    </div>
</div>

<script>
// Fungsi untuk membersihkan input waktu
document.querySelectorAll('.btn-clear').forEach(btn => {
    btn.addEventListener('click', function() {
        const day = this.getAttribute('data-day');
        document.querySelector(`input[name="${day}_start"]`).value = '';
        document.querySelector(`input[name="${day}_end"]`).value = '';
    });
});
</script>

<?php include '../includes/footer.php'; ?>