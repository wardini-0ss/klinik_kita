<?php
include '../config/database.php'; 
include '../includes/auth.php';

// Ensure only doctors can access
if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

// Get doctor information
$doctor_id = $_SESSION['user_id'];
$doctor_stmt = $conn->prepare("SELECT specialization FROM doctors WHERE id = ?");
$doctor_stmt->bind_param("i", $doctor_id);
$doctor_stmt->execute();
$doctor_result = $doctor_stmt->get_result();
$doctor_info = $doctor_result->fetch_assoc();
$doctor_stmt->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3>Dokter Dashboard</h3>
            <p class="text-muted">Selamat datang, Dr. <?= htmlspecialchars($_SESSION['name']) ?> 
                <?php if (!empty($doctor_info['specialization'])): ?>
                    <span class="badge bg-info"><?= htmlspecialchars($doctor_info['specialization']) ?></span>
                <?php endif; ?>
            </p>
        </div>
        <div>
            <span class="badge bg-light text-dark"><?= date('l, d F Y') ?></span>
        </div>
    </div>
    
    <div class="row">
        <!-- Today's Appointments -->
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5>Janji Hari Ini</h5>
                    <a href="appointments.php" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <?php
                    $today = date('Y-m-d');
                    $stmt = $conn->prepare("
                        SELECT a.id, a.appointment_time, p.name as patient_name, p.gender, p.birth_date, a.complaint, a.status 
                        FROM appointments a
                        JOIN patients p ON a.patient_id = p.id
                        WHERE a.doctor_id = ? 
                        AND a.appointment_date = ?
                        ORDER BY a.appointment_time
                    ");
                    $stmt->bind_param("is", $doctor_id, $today);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Waktu</th>
                                        <th>Pasien</th>
                                        <th>Info</th>
                                        <th>Keluhan</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $result->fetch_assoc()): 
                                        $age = date_diff(date_create($row['birth_date']), date_create('today'))->y;
                                    ?>
                                        <tr>
                                            <td><?= date('H:i', strtotime($row['appointment_time'])) ?></td>
                                            <td><?= htmlspecialchars($row['patient_name']) ?></td>
                                            <td>
                                                <span class="badge bg-<?= $row['gender'] == 'L' ? 'primary' : 'danger' ?>">
                                                    <?= $row['gender'] == 'L' ? 'Laki-laki' : 'Perempuan' ?>
                                                </span>
                                                <span class="badge bg-secondary"><?= $age ?> tahun</span>
                                            </td>
                                            <td><?= htmlspecialchars($row['complaint']) ?></td>
                                            <td>
                                                <span class="badge bg-<?= 
                                                    $row['status'] == 'completed' ? 'success' : 
                                                    ($row['status'] == 'confirmed' ? 'info' : 'warning')
                                                ?>">
                                                    <?= ucfirst($row['status']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="medical_record.php?appointment_id=<?= $row['id'] ?>" 
                                                   class="btn btn-sm btn-primary" title="Rekam Medis">
                                                    <i class="fas fa-file-medical"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Tidak ada janji temu hari ini.</div>
                    <?php endif; 
                    $stmt->close();
                    ?>
                </div>
            </div>
            
            <!-- Upcoming Appointments -->
            <div class="card">
                <div class="card-header">
                    <h5>Janji Mendatang (7 Hari)</h5>
                </div>
                <div class="card-body">
                    <?php
                    $start_date = date('Y-m-d');
                    $end_date = date('Y-m-d', strtotime('+7 days'));
                    
                    $stmt = $conn->prepare("
                        SELECT a.appointment_date, COUNT(*) as appointment_count
                        FROM appointments a
                        WHERE a.doctor_id = ? 
                        AND a.appointment_date BETWEEN ? AND ?
                        GROUP BY a.appointment_date
                        ORDER BY a.appointment_date
                    ");
                    $stmt->bind_param("iss", $doctor_id, $start_date, $end_date);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    
                    if ($result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Hari</th>
                                        <th>Jumlah Janji</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $result->fetch_assoc()): 
                                        $day_name = date('l', strtotime($row['appointment_date']));
                                    ?>
                                        <tr>
                                            <td><?= date('d/m/Y', strtotime($row['appointment_date'])) ?></td>
                                            <td><?= $day_name ?></td>
                                            <td>
                                                <span class="badge bg-primary"><?= $row['appointment_count'] ?></span>
                                            </td>
                                            <td>
                                                <a href="appointments.php?date=<?= $row['appointment_date'] ?>" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    Lihat Detail
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">Tidak ada janji temu dalam 7 hari ke depan.</div>
                    <?php endif; 
                    $stmt->close();
                    ?>
                </div>
            </div>
        </div>
        
        <!-- Right Sidebar -->
        <div class="col-md-4">
            <!-- Practice Schedule -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5>Jadwal Praktek</h5>
                    <a href="edit_schedule.php" class="btn btn-sm btn-outline-secondary">Edit</a>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php
                        $stmt = $conn->prepare("
                            SELECT day, start_time, end_time 
                            FROM schedules 
                            WHERE doctor_id = ?
                            ORDER BY FIELD(day, 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu')
                        ");
                        $stmt->bind_param("i", $doctor_id);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0):
                            while ($row = $result->fetch_assoc()):
                                $is_today = date('l') == $row['day'] ? 'border-start border-3 border-primary' : '';
                        ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center <?= $is_today ?>">
                                    <?= $row['day'] ?>
                                    <span class="badge bg-primary rounded-pill">
                                        <?= date('H:i', strtotime($row['start_time'])) ?> - <?= date('H:i', strtotime($row['end_time'])) ?>
                                    </span>
                                </li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li class="list-group-item text-center text-muted">Belum ada jadwal</li>
                        <?php endif; 
                        $stmt->close();
                        ?>
                    </ul>
                </div>
            </div>
            
            <!-- Statistics -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Statistik</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <p class="mb-1">Total Pasien Bulan Ini:</p>
                        <h4 class="text-primary">
                            <?php
                            $month = date('Y-m');
                            $stmt = $conn->prepare("
                                SELECT COUNT(DISTINCT patient_id) 
                                FROM appointments 
                                WHERE doctor_id = ? 
                                AND appointment_date LIKE CONCAT(?, '%')
                            ");
                            $stmt->bind_param("is", $doctor_id, $month);
                            $stmt->execute();
                            $stmt->bind_result($patient_count);
                            $stmt->fetch();
                            echo $patient_count;
                            $stmt->close();
                            ?>
                        </h4>
                    </div>
                    
                    <div class="mb-3">
                        <p class="mb-1">Rata-rata Pasien per Hari:</p>
                        <h4 class="text-primary">
                            <?php
                            $stmt = $conn->prepare("
                                SELECT IFNULL(AVG(cnt), 0) FROM (
                                    SELECT COUNT(*) as cnt 
                                    FROM appointments 
                                    WHERE doctor_id = ? 
                                    AND appointment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
                                    GROUP BY appointment_date
                                ) as daily_counts
                            ");
                            $stmt->bind_param("i", $doctor_id);
                            $stmt->execute();
                            $stmt->bind_result($avg_patients);
                            $stmt->fetch();
                            echo round($avg_patients, 1);
                            $stmt->close();
                            ?>
                        </h4>
                    </div>
                    
                    <div class="mb-3">
                        <p class="mb-1">Janji yang Dikonfirmasi:</p>
                        <div class="progress">
                            <?php
                            $stmt = $conn->prepare("
                                SELECT 
                                    SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END) as confirmed,
                                    COUNT(*) as total
                                FROM appointments
                                WHERE doctor_id = ?
                                AND appointment_date >= CURDATE()
                            ");
                            $stmt->bind_param("i", $doctor_id);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            $stats = $result->fetch_assoc();
                            $percentage = $stats['total'] > 0 ? ($stats['confirmed'] / $stats['total']) * 100 : 0;
                            $stmt->close();
                            ?>
                            <div class="progress-bar bg-success" role="progressbar" 
                                 style="width: <?= $percentage ?>%" 
                                 aria-valuenow="<?= $percentage ?>" 
                                 aria-valuemin="0" 
                                 aria-valuemax="100">
                                <?= round($percentage) ?>%
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h5>Aksi Cepat</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="medical_records.php" class="btn btn-outline-primary">
                            <i class="fas fa-folder-open me-2"></i>Rekam Medis
                        </a>
                        <a href="prescriptions.php" class="btn btn-outline-success">
                            <i class="fas fa-prescription me-2"></i>Resep Obat
                        </a>
                        <a href="edit_profile.php" class="btn btn-outline-info">
                            <i class="fas fa-user-edit me-2"></i>Edit Profil
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>