<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Get current doctor data - MODIFIED TO USE DOCTORS TABLE DIRECTLY
$stmt = $conn->prepare("
    SELECT * FROM doctors WHERE id = ?
");
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();
$doctor = $result->fetch_assoc();
$stmt->close();

// Check if doctor data was found
if (!$doctor) {
    $_SESSION['error_message'] = "Data dokter tidak ditemukan";
    header("Location: dashboard.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $specialization = $_POST['specialization'];
    $phone = $_POST['phone'];
    $bio = $_POST['bio'] ?? null;
    $room_number = $_POST['room_number'] ?? null;
    
    try {
        // Update doctors table
        $stmt = $conn->prepare("
            UPDATE doctors SET 
                name = ?,
                email = ?,
                specialization = ?,
                phone = ?,
                bio = ?,
                room_number = ?
            WHERE id = ?
        ");
        $stmt->bind_param("ssssssi", 
            $name, $email, $specialization, $phone, $bio, $room_number, $doctor_id);
        $stmt->execute();
        
        // Update session
        $_SESSION['name'] = $name;
        $_SESSION['email'] = $email;
        
        $_SESSION['success_message'] = "Profil berhasil diperbarui";
        header("Location: edit_profile.php");
        exit();
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Gagal memperbarui profil: " . $e->getMessage();
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Edit Profil Dokter</h3>
        <a href="dashboard.php" class="btn btn-outline-secondary">Kembali ke Dashboard</a>
    </div>

    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success_message'] ?></div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger"><?= $_SESSION['error_message'] ?></div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="name" name="name" 
                               value="<?= htmlspecialchars($doctor['name'] ?? '') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?= htmlspecialchars($doctor['email'] ?? '') ?>" required>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="specialization" class="form-label">Spesialisasi</label>
                        <input type="text" class="form-control" id="specialization" name="specialization" 
                               value="<?= htmlspecialchars($doctor['specialization'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="phone" class="form-label">Telepon</label>
                        <input type="text" class="form-control" id="phone" name="phone" 
                               value="<?= htmlspecialchars($doctor['phone'] ?? '') ?>">
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="room_number" class="form-label">Nomor Ruangan</label>
                        <input type="text" class="form-control" id="room_number" name="room_number" 
                               value="<?= htmlspecialchars($doctor['room_number'] ?? '') ?>">
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="bio" class="form-label">Bio</label>
                    <textarea class="form-control" id="bio" name="bio" rows="3"><?= 
                        htmlspecialchars($doctor['bio'] ?? '')
                    ?></textarea>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>