<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Get prescriptions - UPDATED TO MATCH YOUR SCHEMA
$stmt = $conn->prepare("
    SELECT 
        p.id,
        p.created_at,
        p.updated_at,
        pt.name as patient_name,
        p.medication,
        p.is_active
    FROM prescriptions p
    JOIN patients pt ON p.patient_id = pt.id
    WHERE p.doctor_id = ?
    ORDER BY p.created_at DESC
");
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$prescriptions = $stmt->get_result();
$stmt->close();
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Manajemen Resep Obat</h3>
        <a href="dashboard.php" class="btn btn-outline-secondary">Kembali ke Dashboard</a>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h5>Daftar Resep</h5>
        </div>
        <div class="card-body">
            <?php if ($prescriptions->num_rows > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Tanggal</th>
                                <th>Pasien</th>
                                <th>Obat</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; while ($prescription = $prescriptions->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= date('d/m/Y', strtotime($prescription['created_at'])) ?></td>
                                    <td><?= htmlspecialchars($prescription['patient_name']) ?></td>
                                    <td><?= htmlspecialchars($prescription['medication']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $prescription['is_active'] ? 'success' : 'secondary' ?>">
                                            <?= $prescription['is_active'] ? 'Aktif' : 'Nonaktif' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="view_prescription.php?id=<?= $prescription['id'] ?>" 
                                           class="btn btn-sm btn-primary">
                                            Lihat Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Belum ada resep yang dibuat.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>