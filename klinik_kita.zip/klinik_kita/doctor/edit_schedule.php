<?php
include '../config/database.php';
include '../includes/auth.php';

if ($_SESSION['role'] != 'doctor') {
    header("Location: ../login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Get current schedule
$days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
$current_schedule = [];

$stmt = $conn->prepare("SELECT day, start_time, end_time FROM schedules WHERE doctor_id = ?");
$stmt->bind_param("i", $doctor_id);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $current_schedule[$row['day']] = [
        'start_time' => $row['start_time'],
        'end_time' => $row['end_time']
    ];
}
$stmt->close();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Begin transaction
    $conn->begin_transaction();
    
    try {
        // First delete all existing schedules for this doctor
        $delete_stmt = $conn->prepare("DELETE FROM schedules WHERE doctor_id = ?");
        $delete_stmt->bind_param("i", $doctor_id);
        $delete_stmt->execute();
        $delete_stmt->close();
        
        // Insert new schedules
        $insert_stmt = $conn->prepare("INSERT INTO schedules (doctor_id, day, start_time, end_time) VALUES (?, ?, ?, ?)");
        
        foreach ($days as $day) {
            if (!empty($_POST[$day]['start_time']) && !empty($_POST[$day]['end_time'])) {
                $start_time = $_POST[$day]['start_time'];
                $end_time = $_POST[$day]['end_time'];
                
                $insert_stmt->bind_param("isss", $doctor_id, $day, $start_time, $end_time);
                $insert_stmt->execute();
            }
        }
        
        $insert_stmt->close();
        $conn->commit();
        $_SESSION['success_message'] = "Jadwal praktek berhasil diperbarui";
        header("Location: edit_schedule.php");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Gagal memperbarui jadwal: " . $e->getMessage();
    }
}
?>

<?php include '../includes/header.php'; ?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Edit Jadwal Praktek</h3>
        <a href="dashboard.php" class="btn btn-outline-secondary">Kembali ke Dashboard</a>
    </div>

    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success_message'] ?></div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger"><?= $_SESSION['error_message'] ?></div>
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Hari</th>
                                <th>Jam Mulai</th>
                                <th>Jam Selesai</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($days as $day): 
                                $current_start = $current_schedule[$day]['start_time'] ?? '';
                                $current_end = $current_schedule[$day]['end_time'] ?? '';
                            ?>
                                <tr>
                                    <td><?= $day ?></td>
                                    <td>
                                        <input type="time" class="form-control" 
                                               name="<?= $day ?>[start_time]" 
                                               value="<?= $current_start ?>">
                                    </td>
                                    <td>
                                        <input type="time" class="form-control" 
                                               name="<?= $day ?>[end_time]" 
                                               value="<?= $current_end ?>">
                                    </td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input schedule-toggle" 
                                                   type="checkbox" 
                                                   id="toggle-<?= $day ?>"
                                                   <?= !empty($current_start) ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="toggle-<?= $day ?>">
                                                <?= !empty($current_start) ? 'Aktif' : 'Nonaktif' ?>
                                            </label>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="d-grid gap-2 mt-4">
                    <button type="submit" class="btn btn-primary">Simpan Jadwal</button>
                    <button type="reset" class="btn btn-outline-secondary">Reset</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Enable/disable time inputs based on toggle switch
document.querySelectorAll('.schedule-toggle').forEach(toggle => {
    toggle.addEventListener('change', function() {
        const row = this.closest('tr');
        const timeInputs = row.querySelectorAll('input[type="time"]');
        
        timeInputs.forEach(input => {
            input.disabled = !this.checked;
            if (!this.checked) {
                input.value = '';
            }
        });
    });
    
    // Trigger change event on page load for initial state
    toggle.dispatchEvent(new Event('change'));
});
</script>

<?php include '../includes/footer.php'; ?>