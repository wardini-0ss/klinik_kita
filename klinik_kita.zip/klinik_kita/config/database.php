<?php
$host = "localhost";
$username = "root"; 
$password = ""; // Kosongkan jika tidak ada password
$database = "klinik_db";

// Buat koneksi
$conn = new mysqli($host, $username, $password, $database);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set charset (tambahkan ini)
$conn->set_charset("utf8mb4");
?>