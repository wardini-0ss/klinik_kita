<?php
include 'config/database.php';

$name = "Admin Utama";
$email = "admin@gmail.com";
$password = "admin123";

// Enkripsi password
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

// Masukkan ke database
$stmt = $conn->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $name, $email, $hashed_password);

if ($stmt->execute()) {
    echo "Akun admin berhasil dibuat!";
} else {
    echo "Gagal membuat akun admin: " . $stmt->error;
}
?>
